"""Regenerate the demo seed data in app/seed/.

    python scripts/make_seed.py

The portal copies app/seed/*.json into instance/data/ on first start. Delete
instance/data/ (or use Admin -> Reset demo data) to start fresh.
"""
import json
import sys
from pathlib import Path

from werkzeug.security import generate_password_hash

SEED = Path(__file__).resolve().parents[1] / "app" / "seed"
SEED.mkdir(parents=True, exist_ok=True)


def dump(name, data):
    (SEED / f"{name}.json").write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# --------------------------------------------------------------------- roles
roles = {
    "admin": {
        "label": "Administrator", "system": True,
        "description": "Full access, including users, roles and module permissions.",
        "permissions": ["*"],
    },
    "hr": {
        "label": "HR Team", "system": True,
        "description": "Runs HR operations: reviews applications and sees all leave.",
        "permissions": ["dashboard.view", "dashboard.org", "forms.view", "forms.review", "leave.view",
                        "leave_approval.view", "leave_approval.all", "directory.view",
                        "directory.sensitive", "profile.view"],
    },
    "manager": {
        "label": "People Manager", "system": True,
        "description": "Approves leave for direct reports and sees team analytics.",
        "permissions": ["dashboard.view", "forms.view", "leave.view", "leave_approval.view",
                        "directory.view", "profile.view"],
    },
    "employee": {
        "label": "Employee", "system": True,
        "description": "Default role: forms, own leave, directory and profile.",
        "permissions": ["forms.view", "leave.view", "directory.view", "profile.view"],
    },
}

# --------------------------------------------------------------------- users
PEOPLE = [
    # id, username, name, designation, dept, grade, manager, roles, location, mode, joined, phone, colour
    ("u1", "admin", "Rohan Mehta", "IT Systems Administrator", "Information Technology", "M2", "u2",
     ["admin", "employee"], "Jaipur", "On-site", "2019-04-15", "+91 98290 11001", "indigo"),
    ("u2", "priya", "Priya Nair", "HR Manager", "Human Resources", "M3", None,
     ["hr", "manager", "employee"], "Jaipur", "Hybrid", "2018-07-02", "+91 98290 11002", "pink"),
    ("u3", "vikram", "Vikram Singh", "Engineering Manager", "Engineering", "M3", "u2",
     ["manager", "employee"], "Jaipur", "Hybrid", "2020-01-20", "+91 98290 11003", "teal"),
    ("u4", "aditi", "Aditi Verma", "Software Engineer II", "Engineering", "E3", "u3",
     ["employee"], "Jaipur", "Hybrid", "2022-08-01", "+91 98290 11004", "violet"),
    ("u5", "arjun", "Arjun Reddy", "Senior Software Engineer", "Engineering", "E4", "u3",
     ["employee"], "Bengaluru", "Remote", "2021-03-15", "+91 98290 11005", "blue"),
    ("u6", "neha", "Neha Kapoor", "QA Engineer", "Engineering", "E2", "u3",
     ["employee"], "Jaipur", "On-site", "2023-06-12", "+91 98290 11006", "coral"),
    ("u7", "kabir", "Kabir Khan", "Data Scientist", "Data & AI", "E3", "u8",
     ["employee"], "Pune", "Hybrid", "2023-01-09", "+91 98290 11007", "emerald"),
    ("u8", "meera", "Meera Iyer", "Head of Data & AI", "Data & AI", "M3", "u2",
     ["manager", "employee"], "Pune", "Hybrid", "2019-11-04", "+91 98290 11008", "amber"),
    ("u9", "sanjay", "Sanjay Gupta", "Finance Executive", "Finance", "E2", "u10",
     ["employee"], "Jaipur", "On-site", "2024-02-19", "+91 98290 11009", "sky"),
    ("u10", "farah", "Farah Sheikh", "Finance Manager", "Finance", "M2", "u2",
     ["manager", "employee"], "Jaipur", "On-site", "2020-09-07", "+91 98290 11010", "violet"),
    ("u11", "ishaan", "Ishaan Joshi", "HR Executive", "Human Resources", "E2", "u2",
     ["hr", "employee"], "Jaipur", "On-site", "2024-07-01", "+91 98290 11011", "pink"),
    ("u12", "divya", "Divya Menon", "UI/UX Designer", "Design", "E3", "u3",
     ["employee"], "Bengaluru", "Remote", "2022-11-21", "+91 98290 11012", "amber"),
    ("u13", "rahul", "Rahul Chauhan", "DevOps Engineer", "Engineering", "E3", "u3",
     ["employee"], "Jaipur", "Hybrid", "2021-10-11", "+91 98290 11013", "slate"),
    ("u14", "pooja", "Pooja Rathore", "Machine Learning Engineer", "Data & AI", "E2", "u8",
     ["employee"], "Pune", "Hybrid", "2025-01-06", "+91 98290 11014", "teal"),
    ("u15", "amit", "Amit Saxena", "Admin & Facilities Executive", "Administration", "E2", "u2",
     ["employee"], "Jaipur", "On-site", "2021-05-24", "+91 98290 11015", "emerald"),
    ("u16", "tanvi", "Tanvi Bansal", "Business Analyst", "Product", "E3", "u3",
     ["employee"], "Jaipur", "Hybrid", "2023-09-18", "+91 98290 11016", "sky", False),
]
DEMO_PASSWORDS = {"admin": "admin123", "priya": "hr123", "vikram": "manager123", "aditi": "employee123"}

users = []
for i, row in enumerate(PEOPLE, start=1):
    (uid, uname, name, desig, dept, grade, mgr, rl, loc, mode, joined, phone, colour, *rest) = row
    pwd = DEMO_PASSWORDS.get(uname, "Welcome@123")
    first, last = name.split()[0].lower(), name.split()[-1].lower()
    users.append({
        "id": uid, "username": uname, "email": f"{first}.{last}@nexora.example",
        "password_hash": generate_password_hash(pwd, method="pbkdf2:sha256"),
        "name": name, "emp_id": f"NX{2018 + (i % 7)}{i:03d}", "designation": desig,
        "department": dept, "grade": grade, "manager_id": mgr, "roles": rl,
        "extra_permissions": [], "revoked_permissions": [],
        "location": f"{loc}, India", "work_mode": mode, "joined_on": joined,
        "phone": phone, "employment_type": "Full-time", "avatar_color": colour,
        "blood_group": ["B+", "O+", "A+", "AB+", "O-", "A-"][i % 6],
        "address": f"{10 + i}, Shanti Nagar, {loc}",
        "emergency_contact": f"Family contact · +91 90010 20{i:03d}",
        "skills": {"Engineering": ["Python", "Flask", "SQL"], "Data & AI": ["PyTorch", "Pandas", "LLMs"],
                   "Design": ["Figma", "Design systems"], "Finance": ["Tally", "Excel"],
                   "Human Resources": ["Talent acquisition", "Payroll"],
                   "Information Technology": ["Linux", "Networking"], "Product": ["Roadmaps", "SQL"],
                   "Administration": ["Vendor mgmt"]}.get(dept, []),
        "active": rest[0] if rest else True,
    })

demo_accounts = [
    {"username": "admin", "password": "admin123", "role": "Administrator", "color": "indigo"},
    {"username": "priya", "password": "hr123", "role": "HR Manager", "color": "pink"},
    {"username": "vikram", "password": "manager123", "role": "Manager", "color": "teal"},
    {"username": "aditi", "password": "employee123", "role": "Employee", "color": "amber"},
]

# --------------------------------------------------------------------- leave
leave_policy = [
    {"code": "CL", "name": "Casual Leave", "annual_quota": 12, "color": "sky", "icon": "bi-cup-hot"},
    {"code": "SL", "name": "Sick Leave", "annual_quota": 10, "color": "coral", "icon": "bi-bandaid"},
    {"code": "EL", "name": "Earned Leave", "annual_quota": 18, "color": "emerald", "icon": "bi-sun"},
    {"code": "CO", "name": "Comp Off", "annual_quota": 4, "color": "violet", "icon": "bi-arrow-repeat"},
    {"code": "LWP", "name": "Leave Without Pay", "annual_quota": 0, "color": "slate", "icon": "bi-slash-circle"},
]


def lv(i, uid, t, f, to, days, status, reason, applied, by=None, on=None, remarks="", half=False):
    return {"id": f"LV{i}", "user_id": uid, "type": t, "from_date": f, "to_date": to, "half_day": half,
            "days": days, "reason": reason, "contact": "", "status": status, "applied_on": applied,
            "decided_by": by, "decided_on": on, "remarks": remarks}


leaves = [
    lv(1, "u4", "CL", "2026-02-16", "2026-02-17", 2, "Approved", "Family function in Udaipur", "2026-02-05T10:12", "u3", "2026-02-05T15:40"),
    lv(2, "u4", "SL", "2026-05-04", "2026-05-04", 1, "Approved", "Fever", "2026-05-04T08:05", "u3", "2026-05-04T09:30"),
    lv(3, "u4", "EL", "2026-07-13", "2026-07-17", 5, "Approved", "Trip to Kerala", "2026-06-20T11:00", "u3", "2026-06-21T10:15"),
    lv(4, "u4", "CL", "2026-10-05", "2026-10-06", 2, "Pending", "Sister's engagement ceremony", "2026-09-25T09:45"),
    lv(5, "u5", "EL", "2026-10-12", "2026-10-16", 5, "Pending", "Annual vacation — Goa", "2026-09-24T18:20"),
    lv(6, "u6", "SL", "2026-09-29", "2026-09-30", 2, "Pending", "Dental procedure and recovery", "2026-09-27T20:05"),
    lv(7, "u13", "CO", "2026-10-09", "2026-10-09", 1, "Pending", "Comp off for weekend release on 20 Sep", "2026-09-22T12:30"),
    lv(8, "u12", "CL", "2026-08-21", "2026-08-21", 1, "Rejected", "Personal work", "2026-08-19T10:00", "u3", "2026-08-19T16:00", "Design review with client scheduled that day; please pick another date."),
    lv(9, "u7", "EL", "2026-10-19", "2026-10-23", 4, "Pending", "Dussehra at home town", "2026-09-26T14:10"),
    lv(10, "u9", "CL", "2026-10-01", "2026-10-01", 0.5, "Pending", "Bank work", "2026-09-28T09:10", half=True),
    lv(11, "u5", "SL", "2026-03-10", "2026-03-11", 2, "Approved", "Viral infection", "2026-03-10T07:50", "u3", "2026-03-10T10:00"),
    lv(12, "u3", "EL", "2026-11-09", "2026-11-13", 4, "Pending", "Diwali with family", "2026-09-20T17:00"),
    lv(13, "u14", "CL", "2026-09-18", "2026-09-18", 1, "Approved", "Convocation", "2026-09-10T11:11", "u8", "2026-09-10T13:00"),
]

holidays = [
    {"date": "2026-10-02", "name": "Gandhi Jayanti", "type": "National"},
    {"date": "2026-10-20", "name": "Dussehra", "type": "Festival"},
    {"date": "2026-11-09", "name": "Diwali (Govardhan Puja)", "type": "Festival"},
    {"date": "2026-11-24", "name": "Guru Nanak Jayanti", "type": "Festival"},
    {"date": "2026-12-25", "name": "Christmas", "type": "Festival"},
    {"date": "2027-01-01", "name": "New Year's Day", "type": "Company"},
    {"date": "2027-01-26", "name": "Republic Day", "type": "National"},
    {"date": "2027-03-22", "name": "Holi", "type": "Festival"},
    {"date": "2027-08-15", "name": "Independence Day", "type": "National"},
]

announcements = [
    {"id": "A1", "title": "Open enrolment for health insurance top-up", "date": "2026-09-25",
     "body": "Add parents or increase your sum insured before 15 October through the Forms section.",
     "tag": "Benefits", "color": "emerald", "pinned": True},
    {"id": "A2", "title": "Townhall: H2 roadmap & awards", "date": "2026-09-22",
     "body": "Join us on 3 October, 4 PM in the Atrium or on the live stream.",
     "tag": "Event", "color": "violet", "pinned": False},
    {"id": "A3", "title": "New access-card readers on Floor 4", "date": "2026-09-18",
     "body": "Old magnetic cards stop working on 31 October. Raise an Access Card form to get a new one.",
     "tag": "Facilities", "color": "amber", "pinned": False},
    {"id": "A4", "title": "Welcome to our new joiners!", "date": "2026-09-15",
     "body": "Say hello to the six people who joined Engineering and Data & AI this month.",
     "tag": "People", "color": "pink", "pinned": False},
]

notifications = [
    {"id": "N1", "user_id": "u4", "text": "Your leave LV3 was approved by Vikram Singh", "link": "/m/leave/",
     "icon": "bi-check-circle", "read": True, "at": "2026-06-21T10:15"},
    {"id": "N2", "user_id": "u4", "text": "New announcement: health insurance top-up", "link": "/",
     "icon": "bi-megaphone", "read": False, "at": "2026-09-25T09:00"},
    {"id": "N3", "user_id": "u3", "text": "4 leave requests are waiting for your approval", "link": "/m/leave_approval/",
     "icon": "bi-inbox", "read": False, "at": "2026-09-27T20:05"},
    {"id": "N4", "user_id": "u2", "text": "Aditi Verma submitted an Access Card Issue form", "link": "/m/forms/review",
     "icon": "bi-file-earmark-text", "read": False, "at": "2026-09-26T11:20"},
    {"id": "N5", "user_id": "u1", "text": "Weekly backup completed successfully", "link": "",
     "icon": "bi-hdd-network", "read": False, "at": "2026-09-27T02:00"},
]

dump("roles", roles)
dump("users", users)
dump("demo_accounts", demo_accounts)
dump("leave_policy", leave_policy)
dump("leaves", leaves)
dump("holidays", holidays)
dump("announcements", announcements)
dump("notifications", notifications)
if not (SEED / "submissions.json").exists() or "--reset-submissions" in sys.argv:
    dump("submissions", [])
print("Seed written to", SEED)
