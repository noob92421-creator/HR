# PeopleHub — HR Portal (UI layer)

A Flask HR portal with one login for everyone. What each person sees depends on
the roles the administrator assigns. The UI is complete and fully clickable. Data
comes from a small JSON "service layer" that stands in for the real database, so
you can build the backend later without touching the pages.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run.py                                          # http://127.0.0.1:5000
pytest -q                                              # 20 tests
```

Demo accounts (click one on the login page to fill it in):

| Username | Password    | Role                        | Sees |
|----------|-------------|-----------------------------|------|
| admin    | admin123    | Administrator               | everything, including Administration |
| priya    | hr123       | HR Manager + Manager        | org dashboard, form review queue, all leave |
| vikram   | manager123  | Engineering Manager         | team dashboard, leave approval for his reports |
| aditi    | employee123 | Employee                    | forms, own leave, directory, profile |

Every other seeded user has the password `Welcome@123`.
Bootstrap, the icons, Chart.js and the font are stored in `app/static/vendor/`, so the portal also works offline.

## Project layout

```
hr_portal/
├── run.py                      # dev server
├── config.py                   # branding, data paths, landing-page fields, disabled modules
├── app/
│   ├── __init__.py             # create_app(): services → hooks → core pages → modules
│   ├── core/
│   │   ├── registry.py         # ★ plug-and-play module registry (PortalModule)
│   │   ├── security.py         # session login, @require(permission), CSRF
│   │   ├── routes.py           # /login, /logout, / (landing page), notifications
│   │   └── templating.py       # filters (date, ago…), sidebar built from the registry
│   ├── services/               # ★ the only data access the UI uses — swap for the real DB
│   │   ├── store.py            # JSON document store (placeholder)
│   │   ├── users.py            # users, roles, permission resolution
│   │   ├── leaves.py           # policy, balances, apply/approve, working-day counter
│   │   └── org.py              # announcements, holidays, notifications, form submissions
│   ├── seed/*.json             # demo data (regenerate: python scripts/make_seed.py)
│   ├── modules/                # ★ one folder per feature
│   │   ├── dashboard/  forms/  leave/  leave_approval/  directory/  profile/  admin/
│   │   └── _template_module/   # copy this to add a module (underscore = ignored)
│   ├── templates/              # base, app shell, login, landing page, macros, errors
│   └── static/                 # css/portal.css (design system), js/portal.js, vendor/
└── tests/test_portal.py
```

## How roles decide what people see

* A **role** (`app/seed/roles.json`) is a list of permissions, e.g. `forms.view`, `leave_approval.view`.
* Each **module** declares an entry permission. The module's card appears on the landing page,
  and its link appears in the sidebar, only if one of the user's roles grants that permission.
* Every route inside a module is protected automatically. Finer actions use
  `@require("forms.review")`.
* Admins can change all of this in the UI: **Administration → Roles & permissions** shows a
  permission matrix, and **Users → Edit access** assigns roles and grants or revokes single
  permissions for one person.

## Add a new module (plug and play)

1. Copy `app/modules/_template_module` to `app/modules/payslips`.
2. In `module.py`, set `key`, `name`, `description`, `icon`, `color` and `permission`.
3. Build the page in `routes.py` and `templates/payslips/index.html`. Extend `layouts/app.html`.
4. Restart the server and tick `payslips.view` for a role under Roles & permissions.

That's all. The registry finds the folder, registers the blueprint at `/m/payslips/`, adds the
sidebar link and home card, and adds its permissions to the admin matrix.
A module can also show a live badge on its card with `badge=lambda user: {"value": 3, "label": "new"}`.
To switch a module off, set `HR_DISABLED_MODULES=payslips`.

## Forms: one YAML file per form type

`app/modules/forms/definitions/*.yaml`. Drop in a new file and it appears in the catalogue
straight away (no restart needed). Each file has:

* **metadata:** title, category (used for the filter chips), icon, colour, short description,
  approver, turnaround time, instructions.
* **`common:`** the shared fields it needs: `name, emp_id, designation, department, manager,
  location, email, phone, date`. These are defined once in `common_fields.yaml` and filled in
  from the user's profile. Identity fields are read-only, and the server ignores tampered values.
* **`fields:`** the form-specific fields. Types: `text, textarea, email, tel, number, date, time, select,
  radio, checkbox, file, section`. Options: `required, min/max` (dates accept `today`, `+7`, `-60`),
  `pattern`, `maxlength`, `width` (`third/half/full…`), `help`, and conditional display with
  `show_if: {field: x, equals|in|contains: …}`.
* **`letter:`** the fixed application format. `to`, `subject` and `body` use Jinja placeholders
  (`{{ name }}`, `{{ from_date|date }}`, `{{ amount|money }}`, `{{ areas|listing('and') }}`, `{% if %}`).
  It runs in a sandbox and HTML is escaped.

The steps for the person filling it in:

1. **Details.** Their fields are filled in for them. As they type, a live preview shows their
   personalised letter, with blanks highlighted. Unsent drafts are kept in the browser.
2. **Review.** They see the finished letter and can print it or save it as PDF.
3. **Submit.** They get a reference number (`REQ-n`) and can track it. The approver is notified.
   HR approves or rejects it from the review queue, and the letter's "For office use" box
   shows the stamped decision.

Included forms: Access Card Issue, Employment/Experience Certificate, NOC (passport / travel /
part-time studies), IT Asset Request, Travel Requisition, Reimbursement Claim, Work From Home,
Address Change.

## Landing page details

The welcome banner shows the user's name, designation, department, roles and grade, plus a row of
detail tiles set by `PROFILE_SUMMARY_FIELDS` in `config.py`. To show a new detail, add a
`(label, user_field, icon)` tuple there.

## Connecting the real backend

Routes and templates only call `services()` (see `app/services/__init__.py`). To connect a
database, re-implement `UserService`, `RoleService`, `LeaveService`, `OrgService` and
`SubmissionService` with the same method names (for example with SQLAlchemy), then build them in
`init_services()`. File uploads (the reimbursement bill) currently record only the file name.
Store the files in the backend.

Before production: set `HR_PORTAL_SECRET_KEY`, set `HR_SHOW_DEMO_ACCOUNTS=0`, and run behind a
WSGI server (for example `gunicorn "app:create_app()"`).
