"""Smoke and behaviour tests for the UI layer.   Run:  pytest -q"""
import re

import pytest

from app import create_app
from config import TestConfig

ACCOUNTS = {"admin": "admin123", "priya": "hr123", "vikram": "manager123", "aditi": "employee123"}


@pytest.fixture()
def app(tmp_path):
    return create_app(TestConfig, DATA_DIR=tmp_path / "data")


@pytest.fixture()
def client(app):
    return app.test_client()


def login(client, username):
    return client.post("/login", data={"login": username, "password": ACCOUNTS[username]}, follow_redirects=True)


# ---------------------------------------------------------------- auth
def test_login_page_renders(client):
    r = client.get("/login")
    assert r.status_code == 200 and b"Welcome back" in r.data


def test_home_requires_login(client):
    r = client.get("/")
    assert r.status_code == 302 and "/login" in r.headers["Location"]


def test_bad_password(client):
    r = client.post("/login", data={"login": "aditi", "password": "nope"}, follow_redirects=True)
    assert b"don&#39;t match" in r.data or b"don't match" in r.data


def test_login_by_email_and_logout(client):
    r = client.post("/login", data={"login": "aditi.verma@nexora.example", "password": "employee123"}, follow_redirects=True)
    assert b"Aditi Verma" in r.data
    r = client.post("/logout", follow_redirects=True)
    assert b"signed out" in r.data


def test_open_redirect_blocked(client):
    r = client.post("/login?next=https://evil.example", data={"login": "aditi", "password": "employee123"})
    assert r.headers["Location"] == "/"


# ---------------------------------------------------------------- role-based cards
EXPECTED = {
    "aditi": {"forms", "leave", "directory", "profile"},
    "vikram": {"dashboard", "forms", "leave", "leave_approval", "directory", "profile"},
    "priya": {"dashboard", "forms", "leave", "leave_approval", "directory", "profile"},
    "admin": {"dashboard", "forms", "leave", "leave_approval", "directory", "profile", "admin"},
}


@pytest.mark.parametrize("user", list(EXPECTED))
def test_home_shows_only_permitted_modules(client, user):
    html = login(client, user).data.decode()
    cards = set(re.findall(r'href="/m/([a-z_]+)/" class="module-card', html))
    assert cards == EXPECTED[user]


@pytest.mark.parametrize("user", list(EXPECTED))
def test_every_page_renders_for_every_role(app, client, user):
    login(client, user)
    reg = app.extensions["module_registry"]
    for m in reg.all():
        r = client.get(f"/m/{m.key}/")
        if m.key in EXPECTED[user]:
            assert r.status_code in (200, 302), (user, m.key, r.status_code)
            if r.status_code == 302:
                assert client.get(r.headers["Location"]).status_code == 200
        else:
            assert r.status_code == 403, (user, m.key)
    for url in ["/m/forms/requests", "/m/directory/u3"]:
        assert client.get(url).status_code == 200, url
    for url in ["/m/admin/users", "/m/admin/roles", "/m/admin/modules"]:
        assert client.get(url).status_code == (200 if user == "admin" else 403)
    assert client.get("/m/forms/review").status_code == (200 if user in ("admin", "priya") else 403)


# ---------------------------------------------------------------- forms engine
def test_every_form_renders(app, client):
    login(client, "aditi")
    from app.modules.forms.engine import FormLibrary
    lib = FormLibrary(app.config["FORMS_DIR"])
    assert lib.all() and not lib.errors
    for f in lib.all():
        r = client.get(f"/m/forms/{f.id}")
        assert r.status_code == 200, f.id
        assert b"Aditi Verma" in r.data  # auto-filled


def test_access_card_full_flow(client):
    login(client, "aditi")
    data = {"phone": "+91 98290 11004", "date": "2026-09-28", "request_type": "Replacement – lost card",
            "old_card_no": "AC-20417", "lost_on": "2026-09-20",
            "access_areas": ["Main entrance", "Basement parking"], "vehicle_no": "RJ14 AB 1234",
            "reason": "Lost it at the metro station."}
    # missing field -> errors
    bad = dict(data, reason="")
    r = client.post("/m/forms/access_card", data={**bad, "action": "review"})
    assert b"Reason / justification is required" in r.data
    # tampering with a read-only field is ignored
    r = client.post("/m/forms/access_card", data={**data, "name": "Someone Else", "action": "review"})
    assert b"Someone Else" not in r.data
    assert b"Confirm & submit" in r.data
    assert b"block the lost card immediately" in r.data
    # live preview endpoint
    r = client.post("/m/forms/access_card/preview", data=data)
    assert r.is_json and "AC-20417" in r.get_json()["html"]
    # submit
    r = client.post("/m/forms/access_card", data={**data, "action": "submit"}, follow_redirects=True)
    assert b"REQ-1" in r.data and b"Pending" in r.data
    assert client.get("/m/forms/requests/REQ-1/print").status_code == 200

    # HR reviews it
    client.post("/logout")
    login(client, "priya")
    assert b"REQ-1" in client.get("/m/forms/review").data
    r = client.post("/m/forms/review/REQ-1", data={"decision": "Rejected", "remarks": ""}, follow_redirects=True)
    assert b"Add a remark" in r.data
    r = client.post("/m/forms/review/REQ-1", data={"decision": "Approved", "remarks": "Collect Monday"}, follow_redirects=True)
    assert b"REQ-1 approved" in r.data

    client.post("/logout")
    login(client, "aditi")
    r = client.get("/m/forms/requests/REQ-1")
    assert b"Approved by Priya Nair" in r.data


def test_employee_cannot_see_others_application(client):
    login(client, "aditi")
    client.post("/m/forms/wfh_request", data={"phone": "+91 90000 00000", "date": "2026-09-28",
                "from_date": "2030-01-06", "to_date": "2030-01-07", "hours": "9:30 AM – 6:30 PM",
                "reason": "Relocating", "wfh_address": "Jaipur", "action": "submit"})
    client.post("/logout")
    login(client, "vikram")
    assert client.get("/m/forms/requests/REQ-1").status_code == 404


# ---------------------------------------------------------------- leave
def test_leave_apply_and_approve(client):
    login(client, "aditi")
    r = client.post("/m/leave/apply", data={"type": "CL", "from_date": "2030-03-04", "to_date": "2030-03-05",
                                            "reason": "Family"}, follow_redirects=True)
    assert b"for 2 day(s) sent for approval" in r.data
    r = client.post("/m/leave/apply", data={"type": "CL", "from_date": "2030-03-05", "to_date": "2030-03-05",
                                            "reason": "Overlap"}, follow_redirects=True)
    assert b"overlap" in r.data
    assert client.get("/m/leave/days?from=2030-03-01&to=2030-03-10").get_json()["days"] == 6
    client.post("/logout")
    login(client, "vikram")
    page = client.get("/m/leave_approval/").data.decode()
    lid = re.findall(r"/m/leave_approval/(LV\d+)/decide", page)
    assert lid
    new_id = max(lid, key=lambda x: int(x[2:]))
    r = client.post(f"/m/leave_approval/{new_id}/decide", data={"decision": "Approved"}, follow_redirects=True)
    assert f"{new_id} approved".encode() in r.data


def test_manager_cannot_approve_other_teams(client):
    login(client, "vikram")
    # LV9 belongs to Kabir (reports to Meera)
    r = client.post("/m/leave_approval/LV9/decide", data={"decision": "Approved"}, follow_redirects=True)
    assert b"can&#39;t act on that request" in r.data or b"can't act" in r.data


# ---------------------------------------------------------------- admin
def test_admin_can_grant_module_to_role(client):
    login(client, "admin")
    roles_page = client.get("/m/admin/roles").data.decode()
    assert "perm__employee" in roles_page
    # give employees the dashboard
    current = ["forms.view", "leave.view", "directory.view", "profile.view", "dashboard.view"]
    form = {"perm__employee": current}
    for role in ("hr", "manager"):
        form[f"perm__{role}"] = re.findall(rf'name="perm__{role}" value="([^"]+)" checked', roles_page)
    client.post("/m/admin/roles", data=form)
    client.post("/logout")
    html = login(client, "aditi").data.decode()
    assert 'href="/m/dashboard/" class="module-card' in html


def test_csrf_enforced_when_enabled(tmp_path):
    from config import Config
    app = create_app(Config, DATA_DIR=tmp_path / "d", TESTING=True)
    c = app.test_client()
    assert c.post("/login", data={"login": "aditi", "password": "employee123"}).status_code == 400
