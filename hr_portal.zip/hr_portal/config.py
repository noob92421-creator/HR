"""Application configuration.

Values can be overridden with environment variables (or a .env file if you
install python-dotenv). Keep secrets out of source control in production.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


class Config:
    SECRET_KEY = os.environ.get("HR_PORTAL_SECRET_KEY", "dev-only-change-me")

    # --- Branding --------------------------------------------------------
    PORTAL_NAME = os.environ.get("HR_PORTAL_NAME", "PeopleHub")
    COMPANY = {
        "name": os.environ.get("HR_COMPANY_NAME", "Nexora Technologies Pvt. Ltd."),
        "short_name": "Nexora",
        "address": "4th Floor, Tower B, Cyber Park, Jaipur, Rajasthan 302017",
        "email": "hr@nexora.example",
        "phone": "+91 141 400 1234",
        "website": "www.nexora.example",
    }

    # --- Data layer ------------------------------------------------------
    # The UI talks to app/services/*. Right now those services are backed by
    # JSON files (a stand-in for the real database). SEED_DIR holds the
    # pristine demo data; DATA_DIR holds the working copy that the UI edits.
    SEED_DIR = BASE_DIR / "app" / "seed"
    DATA_DIR = Path(os.environ.get("HR_PORTAL_DATA_DIR", BASE_DIR / "instance" / "data"))

    # --- Modules & forms -------------------------------------------------
    # Modules are discovered automatically from app/modules/. List keys here
    # to switch a module off without deleting its folder.
    DISABLED_MODULES = [m for m in os.environ.get("HR_DISABLED_MODULES", "").split(",") if m]
    FORMS_DIR = BASE_DIR / "app" / "modules" / "forms" / "definitions"

    # --- Landing page ----------------------------------------------------
    # Details shown in the welcome banner. Add a row here when the user
    # record gains a new attribute: (label, user-record key, Bootstrap icon).
    PROFILE_SUMMARY_FIELDS = [
        ("Employee ID", "emp_id", "bi-person-vcard"),
        ("Department", "department", "bi-diagram-3"),
        ("Reporting to", "manager_name", "bi-person-up"),
        ("Location", "location", "bi-geo-alt"),
        ("Work mode", "work_mode", "bi-laptop"),
        ("Joined", "joined_on", "bi-calendar-heart"),
    ]

    # --- Login page ------------------------------------------------------
    SHOW_DEMO_ACCOUNTS = os.environ.get("HR_SHOW_DEMO_ACCOUNTS", "1") == "1"

    # --- Session ---------------------------------------------------------
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 8  # 8 hours with "remember me"
    TEMPLATES_AUTO_RELOAD = True


class TestConfig(Config):
    TESTING = True
    WTF_CSRF_ENABLED = False
    CSRF_ENABLED = False
