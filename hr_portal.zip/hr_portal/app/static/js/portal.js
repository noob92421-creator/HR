/* PeopleHub — small, dependency-free UI helpers (Bootstrap bundle provides modals/dropdowns). */
(function () {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const csrf = () => (document.querySelector('meta[name="csrf-token"]') || {}).content || "";
  const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  const store = {                      // localStorage can be unavailable (private mode) — never let it break the page
    get(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
    del(k) { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } },
  };
  window.Portal = { $, $$, csrf, debounce, store };

  /* ---------------------------------------------------------------- sidebar */
  document.addEventListener("click", (e) => {
    if (e.target.closest("[data-sidebar-toggle]")) document.body.classList.toggle("sidebar-open");
    else if (e.target.closest(".sidebar-backdrop")) document.body.classList.remove("sidebar-open");
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") document.body.classList.remove("sidebar-open"); });

  /* ---------------------------------------------------------------- toasts */
  function dismiss(t) { t.classList.add("hide"); setTimeout(() => t.remove(), 300); }
  $$(".toast-portal").forEach((t) => {
    const ms = t.dataset.level === "danger" ? 9000 : 5000;
    setTimeout(() => dismiss(t), ms);
    const x = $(".btn-close", t); if (x) x.addEventListener("click", () => dismiss(t));
  });

  /* ---------------------------------------------------------- notifications */
  const bell = $("#notifBell");
  if (bell) {
    bell.addEventListener("shown.bs.dropdown", () => {
      const dot = $(".notif-dot", bell);
      if (!dot) return;
      fetch(bell.dataset.readUrl, { method: "POST", headers: { "X-CSRF-Token": csrf(), "Accept": "application/json" } })
        .then(() => dot.remove()).catch(() => {});
    });
  }

  /* ---------------------------------------------------------------- confirm */
  document.addEventListener("submit", (e) => {
    const f = e.target;
    const msg = f.dataset.confirm || (e.submitter && e.submitter.dataset.confirm);
    if (msg && !window.confirm(msg)) e.preventDefault();
  });

  /* --------------------------------------------------------- password eye */
  $$("[data-toggle-password]").forEach((btn) => btn.addEventListener("click", () => {
    const input = $(btn.dataset.togglePassword);
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    btn.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
    btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
  }));

  /* ------------------------------------------------------ client filtering */
  // <input data-filter="#grid"> filters children with data-search text; chips with data-filter-cat
  $$("[data-filter]").forEach((input) => {
    const grid = $(input.dataset.filter);
    const chips = $$(`[data-filter-for="${input.dataset.filter}"]`);
    const empty = $(input.dataset.empty || "#noResults");
    let cat = "";
    const apply = () => {
      const q = input.value.trim().toLowerCase();
      let shown = 0;
      $$("[data-search]", grid).forEach((el) => {
        const ok = (!q || el.dataset.search.includes(q)) && (!cat || el.dataset.cat === cat);
        el.hidden = !ok; if (ok) shown++;
      });
      if (empty) empty.hidden = shown > 0;
    };
    input.addEventListener("input", apply);
    chips.forEach((c) => c.addEventListener("click", () => {
      chips.forEach((x) => { x.classList.remove("active"); x.setAttribute("aria-pressed", "false"); });
      c.classList.add("active"); c.setAttribute("aria-pressed", "true");
      cat = c.dataset.cat || ""; apply();
    }));
    document.addEventListener("keydown", (e) => {
      if (e.key === "/" && !/input|textarea|select/i.test(document.activeElement.tagName)) { e.preventDefault(); input.focus(); }
    });
  });

  /* ------------------------------------------------------- select all rows */
  $$("[data-select-all]").forEach((master) => {
    const boxes = () => $$(master.dataset.selectAll);
    const bar = $(master.dataset.bar || "");
    const sync = () => {
      const n = boxes().filter((b) => b.checked).length;
      if (bar) { bar.hidden = n === 0; const c = $("[data-count]", bar); if (c) c.textContent = n; }
      boxes().forEach((b) => { const card = b.closest(".request-card"); if (card) card.classList.toggle("is-selected", b.checked); });
      master.checked = n > 0 && n === boxes().length; master.indeterminate = n > 0 && n < boxes().length;
    };
    master.addEventListener("change", () => { boxes().forEach((b) => (b.checked = master.checked)); sync(); });
    document.addEventListener("change", (e) => { if (e.target.matches(master.dataset.selectAll)) sync(); });
    sync();
  });

  /* ------------------------------------------------ modal filled from button */
  // <button data-bs-toggle="modal" data-bs-target="#m" data-fill='{"#m .x": "value"}' data-action="/url">
  document.addEventListener("show.bs.modal", (e) => {
    const btn = e.relatedTarget; if (!btn) return;
    const modal = e.target;
    if (btn.dataset.action) { const f = $("form", modal); if (f) f.action = btn.dataset.action; }
    if (btn.dataset.fill) {
      const map = JSON.parse(btn.dataset.fill);
      Object.entries(map).forEach(([sel, val]) => $$(sel, modal).forEach((el) => {
        if (el.type === "checkbox") el.checked = Array.isArray(val) ? val.includes(el.value) : !!val;
        else if ("value" in el && el.tagName !== "DIV" && el.tagName !== "SPAN") el.value = val == null ? "" : val;
        else el.textContent = val;
      }));
    }
  });

  /* ============================================================ forms engine */
  const formEl = $("form[data-dynamic-form]");
  if (formEl) {
    const previewUrl = formEl.dataset.previewUrl;
    const target = $("#letterPreview");
    const draftKey = "draft:" + formEl.dataset.formId;

    const values = () => {
      const fd = new FormData(formEl), out = {};
      for (const [k, v] of fd.entries()) {
        if (k === "csrf_token" || k === "action") continue;
        (out[k] = out[k] || []).push(v);
      }
      $$("input[type=file]", formEl).forEach((f) => { out[f.name + "__name"] = [f.files[0] ? f.files[0].name : ""]; });
      return out;
    };

    const matches = (rule, vals) => {
      const other = vals[rule.field] || [];
      if ("equals" in rule) return other[0] === rule.equals;
      if ("in" in rule) return rule.in.includes(other[0]);
      if ("contains" in rule) return other.includes(rule.contains);
      if ("not_empty" in rule) return other.some(Boolean);
      return true;
    };

    const applyVisibility = () => {
      const vals = values();
      $$("[data-show-if]", formEl).forEach((wrap) => {
        const show = matches(JSON.parse(wrap.dataset.showIf), vals);
        if (wrap.hidden === show) {
          wrap.hidden = !show;
          if (show) { wrap.classList.remove("reveal"); void wrap.offsetWidth; wrap.classList.add("reveal"); }
        }
        $$("input,select,textarea", wrap).forEach((el) => (el.disabled = !show));
      });
    };

    const refreshPreview = debounce(() => {
      if (!target || !previewUrl) return;
      const fd = new FormData(formEl);
      $$("input[type=file]", formEl).forEach((f) => fd.set(f.name + "__name", f.files[0] ? f.files[0].name : ""));
      fetch(previewUrl, { method: "POST", body: fd, headers: { "X-CSRF-Token": csrf() } })
        .then((r) => (r.ok ? r.json() : null))
        .then((data) => { if (data) target.innerHTML = data.html; })
        .catch(() => {});
    }, 250);

    const saveDraft = debounce(() => {
      const vals = values();
      $$("[readonly]", formEl).forEach((el) => delete vals[el.name]);
      store.set(draftKey, { at: Date.now(), vals });
    }, 400);

    // restore an unsent draft (per browser) if the page has no server-side values posted back
    if (formEl.dataset.restore === "1") {
      const draft = store.get(draftKey);
      if (draft && Date.now() - draft.at < 7 * 864e5) {
        Object.entries(draft.vals).forEach(([name, vals]) => {
          $$(`[name="${CSS.escape(name)}"]`, formEl).forEach((el) => {
            if (el.readOnly || el.type === "file" || el.type === "hidden") return;
            if (el.type === "checkbox" || el.type === "radio") el.checked = vals.includes(el.value);
            else el.value = vals[0] || "";
          });
        });
        const note = $("#draftNote"); if (note) note.hidden = false;
      }
    }
    const clearBtn = $("#clearDraft");
    if (clearBtn) clearBtn.addEventListener("click", () => { store.del(draftKey); window.location.reload(); });

    formEl.addEventListener("input", () => { applyVisibility(); refreshPreview(); saveDraft(); });
    formEl.addEventListener("change", () => { applyVisibility(); refreshPreview(); saveDraft(); });
    applyVisibility();
    refreshPreview();
  }
  // the review step's final submit clears the stored draft
  const confirmForm = $("form[data-clear-draft]");
  if (confirmForm) confirmForm.addEventListener("submit", () => store.del("draft:" + confirmForm.dataset.clearDraft));

  /* ============================================================ leave dialog */
  const leaveForm = $("#leaveForm");
  if (leaveForm) {
    const from = $("[name=from_date]", leaveForm), to = $("[name=to_date]", leaveForm);
    const half = $("[name=half_day]", leaveForm), type = $("[name=type]", leaveForm);
    const out = $("#daysOut"), bal = $("#balanceOut");
    const update = debounce(() => {
      if (half.checked && from.value) to.value = from.value;
      to.disabled = half.checked;
      if (from.value && (!to.value || to.value < from.value)) to.value = from.value;
      to.min = from.value || to.min;
      const opt = type.selectedOptions[0];
      bal.textContent = opt && opt.dataset.available ? `${opt.dataset.available} day(s) available` : "No fixed quota";
      if (!from.value) { out.textContent = "Pick your dates"; return; }
      const q = new URLSearchParams({ from: from.value, to: to.value || from.value, half: half.checked ? "1" : "0" });
      fetch(leaveForm.dataset.daysUrl + "?" + q).then((r) => r.json()).then((d) => {
        out.textContent = d.days == null ? "Pick your dates" : `${d.days} working day${d.days === 1 ? "" : "s"}`;
      }).catch(() => {});
    }, 150);
    [from, to, half, type].forEach((el) => el.addEventListener("change", update));
    leaveForm.addEventListener("submit", () => { to.disabled = false; });
    update();
  }

  /* ============================================================== login page */
  $$("[data-demo-login]").forEach((b) => b.addEventListener("click", () => {
    $("#login").value = b.dataset.demoLogin;
    $("#password").value = b.dataset.demoPassword;
    $("#password").focus();
  }));
})();
