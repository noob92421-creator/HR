"""Service layer: the only place the UI gets data from.

``init_services(app)`` builds the services and stores them on
``app.extensions['services']``; use ``services()`` inside a request.
Swap the implementations here for database-backed ones later.
"""
from __future__ import annotations

from types import SimpleNamespace

from flask import Flask, current_app

from .leaves import LeaveError, LeaveService
from .org import OrgService, SubmissionService
from .store import JsonStore
from .users import RoleService, User, UserService

__all__ = ["init_services", "services", "User", "LeaveError"]


def init_services(app: Flask) -> None:
    store = JsonStore(app.config["DATA_DIR"], app.config["SEED_DIR"])
    roles = RoleService(store)
    app.extensions["services"] = SimpleNamespace(
        store=store,
        roles=roles,
        users=UserService(store, roles),
        leaves=LeaveService(store),
        org=OrgService(store),
        submissions=SubmissionService(store),
    )


def services() -> SimpleNamespace:
    return current_app.extensions["services"]
