"""Tiny JSON document store — the placeholder for the real database.

Each "collection" is one JSON file in DATA_DIR. On first start the files are
copied from app/seed/. Writes are atomic (temp file + rename) and guarded by a
lock, which is plenty for a single-process development server.

When the real backend is ready, re-implement the service classes in this
package against the database; the routes and templates only call services.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import threading
from pathlib import Path
from typing import Any

_lock = threading.RLock()


class JsonStore:
    def __init__(self, data_dir: Path, seed_dir: Path):
        self.data_dir = Path(data_dir)
        self.seed_dir = Path(seed_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        for seed in self.seed_dir.glob("*.json"):
            target = self.data_dir / seed.name
            if not target.exists():
                shutil.copy(seed, target)

    def _path(self, name: str) -> Path:
        return self.data_dir / f"{name}.json"

    def read(self, name: str, default: Any = None) -> Any:
        with _lock:
            path = self._path(name)
            if not path.exists():
                return [] if default is None else default
            with path.open(encoding="utf-8") as fh:
                return json.load(fh)

    def write(self, name: str, data: Any) -> None:
        with _lock:
            path = self._path(name)
            fd, tmp = tempfile.mkstemp(dir=self.data_dir, suffix=".tmp")
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2, ensure_ascii=False)
            os.replace(tmp, path)

    def next_id(self, items: list[dict], prefix: str = "") -> str:
        nums = [int(str(i["id"]).removeprefix(prefix)) for i in items
                if str(i.get("id", "")).removeprefix(prefix).isdigit()]
        return f"{prefix}{(max(nums) + 1) if nums else 1}"

    def reset(self) -> None:
        """Restore every collection from the seed files (demo reset)."""
        with _lock:
            for seed in self.seed_dir.glob("*.json"):
                shutil.copy(seed, self.data_dir / seed.name)
