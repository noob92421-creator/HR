"""Users, roles and permissions."""
from __future__ import annotations

from datetime import date
from typing import Iterable, Optional

from werkzeug.security import check_password_hash, generate_password_hash

from .store import JsonStore


class User:
    """Read-only view of a user record plus resolved permissions."""

    def __init__(self, record: dict, permissions: Iterable[str], role_labels: list[str]):
        self._r = record
        self.permissions = frozenset(permissions)
        self.role_labels = role_labels

    def __getattr__(self, item):
        try:
            return self._r[item]
        except KeyError:
            raise AttributeError(item) from None

    def get(self, key, default=None):
        return self._r.get(key, default)

    def to_dict(self) -> dict:
        data = {k: v for k, v in self._r.items() if k != "password_hash"}
        data["role_labels"] = self.role_labels
        return data

    # --------------------------------------------------------------- perms
    def can(self, permission: str) -> bool:
        if "*" in self.permissions or permission in self.permissions:
            return True
        prefix = permission.split(".")[0]
        return f"{prefix}.*" in self.permissions

    def can_any(self, *permissions: str) -> bool:
        return any(self.can(p) for p in permissions)

    # --------------------------------------------------------------- display
    @property
    def first_name(self) -> str:
        return self._r["name"].split()[0]

    @property
    def initials(self) -> str:
        parts = self._r["name"].split()
        return (parts[0][0] + (parts[-1][0] if len(parts) > 1 else "")).upper()

    @property
    def tenure(self) -> str:
        try:
            joined = date.fromisoformat(self._r["joined_on"])
        except (KeyError, ValueError):
            return "—"
        months = (date.today().year - joined.year) * 12 + date.today().month - joined.month
        years, months = divmod(max(months, 0), 12)
        bits = []
        if years:
            bits.append(f"{years} yr" + ("s" if years > 1 else ""))
        if months or not years:
            bits.append(f"{months} mo")
        return " ".join(bits)


class RoleService:
    def __init__(self, store: JsonStore):
        self.store = store

    def all(self) -> dict[str, dict]:
        return self.store.read("roles", {})

    def get(self, key: str) -> Optional[dict]:
        return self.all().get(key)

    def permissions_for(self, role_keys: Iterable[str]) -> set[str]:
        roles = self.all()
        perms: set[str] = set()
        for key in role_keys:
            perms.update(roles.get(key, {}).get("permissions", []))
        return perms

    def set_permissions(self, key: str, permissions: list[str]) -> None:
        roles = self.all()
        if key not in roles:
            raise KeyError(key)
        roles[key]["permissions"] = sorted(set(permissions))
        self.store.write("roles", roles)

    def create(self, key: str, label: str, description: str = "") -> None:
        roles = self.all()
        if key in roles:
            raise ValueError(f"Role '{key}' already exists")
        roles[key] = {"label": label, "description": description, "permissions": [], "system": False}
        self.store.write("roles", roles)

    def delete(self, key: str) -> None:
        roles = self.all()
        if roles.get(key, {}).get("system"):
            raise ValueError("System roles cannot be deleted")
        roles.pop(key, None)
        self.store.write("roles", roles)


class UserService:
    def __init__(self, store: JsonStore, roles: RoleService):
        self.store = store
        self.roles = roles

    # ------------------------------------------------------------ internal
    def _records(self) -> list[dict]:
        return self.store.read("users", [])

    def _save(self, records: list[dict]) -> None:
        self.store.write("users", records)

    def _wrap(self, rec: dict) -> User:
        role_keys = rec.get("roles", [])
        perms = self.roles.permissions_for(role_keys) | set(rec.get("extra_permissions", []))
        perms -= set(rec.get("revoked_permissions", []))
        roles = self.roles.all()
        labels = [roles[k]["label"] for k in role_keys if k in roles]
        return User(rec, perms, labels)

    # ------------------------------------------------------------ queries
    def get(self, user_id: str) -> Optional[User]:
        rec = next((r for r in self._records() if r["id"] == user_id), None)
        return self._wrap(rec) if rec else None

    def all(self, include_inactive: bool = True) -> list[User]:
        return [self._wrap(r) for r in self._records() if include_inactive or r.get("active", True)]

    def team_of(self, manager_id: str) -> list[User]:
        return [self._wrap(r) for r in self._records() if r.get("manager_id") == manager_id]

    def profile_record(self, user: User) -> dict:
        """User data enriched with derived values (e.g. manager_name) for forms."""
        data = user.to_dict()
        manager = self.get(user.get("manager_id")) if user.get("manager_id") else None
        data["manager_name"] = manager.name if manager else ""
        data["manager_designation"] = manager.designation if manager else ""
        return data

    def departments(self) -> list[str]:
        return sorted({r.get("department", "") for r in self._records() if r.get("department")})

    def authenticate(self, login: str, password: str) -> Optional[User]:
        login = (login or "").strip().lower()
        for rec in self._records():
            if login in (rec["username"].lower(), rec.get("email", "").lower()):
                if rec.get("active", True) and check_password_hash(rec["password_hash"], password or ""):
                    return self._wrap(rec)
                return None
        return None

    # ------------------------------------------------------------ commands
    def update(self, user_id: str, **fields) -> User:
        records = self._records()
        for rec in records:
            if rec["id"] == user_id:
                rec.update({k: v for k, v in fields.items() if k not in ("id", "password_hash")})
                self._save(records)
                return self._wrap(rec)
        raise KeyError(user_id)

    def set_password(self, user_id: str, new_password: str) -> None:
        records = self._records()
        for rec in records:
            if rec["id"] == user_id:
                rec["password_hash"] = generate_password_hash(new_password)
                self._save(records)
                return
        raise KeyError(user_id)

    def check_password(self, user_id: str, password: str) -> bool:
        rec = next((r for r in self._records() if r["id"] == user_id), None)
        return bool(rec) and check_password_hash(rec["password_hash"], password or "")

    def create(self, data: dict, password: str) -> User:
        records = self._records()
        uname = data["username"].strip().lower()
        if any(r["username"].lower() == uname for r in records):
            raise ValueError("Username already taken")
        if data.get("email") and any(r.get("email", "").lower() == data["email"].lower() for r in records):
            raise ValueError("Email already registered")
        rec = {
            "id": self.store.next_id(records, "u"),
            "active": True,
            "extra_permissions": [],
            "revoked_permissions": [],
            "joined_on": date.today().isoformat(),
            **data,
            "username": uname,
            "password_hash": generate_password_hash(password),
        }
        records.append(rec)
        self._save(records)
        return self._wrap(rec)
