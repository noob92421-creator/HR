"""Leave policy, balances, applications and approvals."""
from __future__ import annotations

from datetime import date, datetime, timedelta
from typing import Optional

from .store import JsonStore


class LeaveError(ValueError):
    pass


class LeaveService:
    def __init__(self, store: JsonStore):
        self.store = store

    # ------------------------------------------------------------ policy
    def policy(self) -> list[dict]:
        return self.store.read("leave_policy", [])

    def leave_type(self, code: str) -> Optional[dict]:
        return next((t for t in self.policy() if t["code"] == code), None)

    def holidays(self) -> set[str]:
        return {h["date"] for h in self.store.read("holidays", [])}

    def working_days(self, start: date, end: date, half_day: bool = False) -> float:
        if end < start:
            return 0
        hol = self.holidays()
        days, cur = 0, start
        while cur <= end:
            if cur.weekday() < 5 and cur.isoformat() not in hol:
                days += 1
            cur += timedelta(days=1)
        if half_day and days:
            return 0.5
        return float(days)

    # ------------------------------------------------------------ queries
    def _all(self) -> list[dict]:
        return self.store.read("leaves", [])

    def get(self, leave_id: str) -> Optional[dict]:
        return next((l for l in self._all() if l["id"] == leave_id), None)

    def for_user(self, user_id: str) -> list[dict]:
        items = [l for l in self._all() if l["user_id"] == user_id]
        return sorted(items, key=lambda l: l["applied_on"], reverse=True)

    def balances(self, user_id: str, year: Optional[int] = None) -> list[dict]:
        year = year or date.today().year
        mine = [l for l in self.for_user(user_id) if l["from_date"].startswith(str(year))]
        out = []
        for t in self.policy():
            used = sum(l["days"] for l in mine if l["type"] == t["code"] and l["status"] == "Approved")
            pending = sum(l["days"] for l in mine if l["type"] == t["code"] and l["status"] == "Pending")
            quota = t["annual_quota"]
            out.append({**t, "used": used, "pending": pending,
                        "available": max(quota - used - pending, 0) if quota else None})
        return out

    def queue(self, approver, users_by_id: dict, include_all: bool = False,
              status: Optional[str] = None) -> list[dict]:
        """Requests the approver may act on (their reports, or everyone for HR)."""
        items = []
        for l in self._all():
            owner = users_by_id.get(l["user_id"])
            if owner is None or l["user_id"] == approver.id:
                continue
            if include_all or owner.get("manager_id") == approver.id:
                if status and l["status"] != status:
                    continue
                items.append({**l, "employee": owner})
        return sorted(items, key=lambda l: (l["status"] != "Pending", l["applied_on"]), reverse=False)

    def pending_count(self, approver, users_by_id: dict, include_all: bool = False) -> int:
        return len(self.queue(approver, users_by_id, include_all, status="Pending"))

    # ------------------------------------------------------------ commands
    def apply(self, user, leave_type: str, from_date: str, to_date: str,
              reason: str, half_day: bool = False, contact: str = "") -> dict:
        t = self.leave_type(leave_type)
        if not t:
            raise LeaveError("Choose a valid leave type.")
        try:
            start, end = date.fromisoformat(from_date), date.fromisoformat(to_date)
        except ValueError:
            raise LeaveError("Enter valid dates.") from None
        if end < start:
            raise LeaveError("The end date can't be before the start date.")
        if half_day and start != end:
            raise LeaveError("A half day must start and end on the same date.")
        if not reason.strip():
            raise LeaveError("Please give a reason.")
        days = self.working_days(start, end, half_day)
        if days == 0:
            raise LeaveError("The selected dates fall on weekends or holidays only.")
        for l in self.for_user(user.id):
            if l["status"] in ("Pending", "Approved") and not (
                    end < date.fromisoformat(l["from_date"]) or start > date.fromisoformat(l["to_date"])):
                raise LeaveError(f"These dates overlap your request {l['id']} ({l['status'].lower()}).")
        if t["annual_quota"]:
            bal = next(b for b in self.balances(user.id, start.year) if b["code"] == leave_type)
            if days > bal["available"]:
                raise LeaveError(f"Only {bal['available']:g} day(s) of {t['name']} available.")
        items = self._all()
        rec = {
            "id": self.store.next_id(items, "LV"),
            "user_id": user.id,
            "type": leave_type,
            "from_date": start.isoformat(),
            "to_date": end.isoformat(),
            "half_day": half_day,
            "days": days,
            "reason": reason.strip(),
            "contact": contact.strip(),
            "status": "Pending",
            "applied_on": datetime.now().isoformat(timespec="minutes"),
            "decided_by": None,
            "decided_on": None,
            "remarks": "",
        }
        items.append(rec)
        self.store.write("leaves", items)
        return rec

    def decide(self, leave_id: str, approver, decision: str, remarks: str = "") -> dict:
        if decision not in ("Approved", "Rejected"):
            raise LeaveError("Unknown decision.")
        if decision == "Rejected" and not remarks.strip():
            raise LeaveError("Add a remark when rejecting a request.")
        items = self._all()
        for l in items:
            if l["id"] == leave_id:
                if l["status"] != "Pending":
                    raise LeaveError(f"{leave_id} is already {l['status'].lower()}.")
                if l["user_id"] == approver.id:
                    raise LeaveError("You can't approve your own request.")
                l.update(status=decision, decided_by=approver.id, remarks=remarks.strip(),
                         decided_on=datetime.now().isoformat(timespec="minutes"))
                self.store.write("leaves", items)
                return l
        raise LeaveError("Request not found.")

    def cancel(self, leave_id: str, user_id: str) -> dict:
        items = self._all()
        for l in items:
            if l["id"] == leave_id and l["user_id"] == user_id:
                if l["status"] != "Pending":
                    raise LeaveError("Only pending requests can be withdrawn.")
                l["status"] = "Withdrawn"
                self.store.write("leaves", items)
                return l
        raise LeaveError("Request not found.")
