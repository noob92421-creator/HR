"""Organisation-wide content: announcements, holidays, notifications, form submissions."""
from __future__ import annotations

from datetime import date, datetime
from typing import Optional

from .store import JsonStore


class OrgService:
    def __init__(self, store: JsonStore):
        self.store = store

    def announcements(self, limit: int = 5) -> list[dict]:
        items = self.store.read("announcements", [])
        # pinned first, then newest first
        return sorted(items, key=lambda a: (a.get("pinned", False), a["date"]), reverse=True)[:limit]

    def upcoming_holidays(self, limit: int = 4) -> list[dict]:
        today = date.today().isoformat()
        items = [h for h in self.store.read("holidays", []) if h["date"] >= today]
        return sorted(items, key=lambda h: h["date"])[:limit]

    # ------------------------------------------------------- notifications
    def notifications(self, user_id: str, limit: int = 8) -> list[dict]:
        items = [n for n in self.store.read("notifications", []) if n["user_id"] == user_id]
        return sorted(items, key=lambda n: n["at"], reverse=True)[:limit]

    def unread_count(self, user_id: str) -> int:
        return sum(1 for n in self.store.read("notifications", []) if n["user_id"] == user_id and not n["read"])

    def notify(self, user_id: str, text: str, link: str = "", icon: str = "bi-bell") -> None:
        items = self.store.read("notifications", [])
        items.append({"id": self.store.next_id(items, "N"), "user_id": user_id, "text": text,
                      "link": link, "icon": icon, "read": False,
                      "at": datetime.now().isoformat(timespec="minutes")})
        self.store.write("notifications", items)

    def mark_all_read(self, user_id: str) -> None:
        items = self.store.read("notifications", [])
        for n in items:
            if n["user_id"] == user_id:
                n["read"] = True
        self.store.write("notifications", items)


class SubmissionService:
    """Stores personalised form applications and their review status."""

    def __init__(self, store: JsonStore):
        self.store = store

    def _all(self) -> list[dict]:
        return self.store.read("submissions", [])

    def get(self, sub_id: str) -> Optional[dict]:
        return next((s for s in self._all() if s["id"] == sub_id), None)

    def for_user(self, user_id: str) -> list[dict]:
        return sorted([s for s in self._all() if s["user_id"] == user_id],
                      key=lambda s: s["submitted_on"], reverse=True)

    def all(self, status: Optional[str] = None) -> list[dict]:
        items = [s for s in self._all() if not status or s["status"] == status]
        return sorted(items, key=lambda s: (s["status"] != "Pending", s["submitted_on"]))

    def create(self, user_id: str, form_id: str, form_title: str, values: dict, letter_html: str) -> dict:
        items = self._all()
        rec = {
            "id": self.store.next_id(items, "REQ-"),
            "user_id": user_id,
            "form_id": form_id,
            "form_title": form_title,
            "values": values,
            "letter_html": letter_html,
            "status": "Pending",
            "submitted_on": datetime.now().isoformat(timespec="minutes"),
            "reviewed_by": None,
            "reviewed_on": None,
            "remarks": "",
        }
        items.append(rec)
        self.store.write("submissions", items)
        return rec

    def decide(self, sub_id: str, reviewer_id: str, decision: str, remarks: str = "") -> dict:
        if decision not in ("Approved", "Rejected"):
            raise ValueError("Unknown decision")
        items = self._all()
        for s in items:
            if s["id"] == sub_id:
                if s["status"] != "Pending":
                    raise ValueError(f"{sub_id} is already {s['status'].lower()}")
                s.update(status=decision, reviewed_by=reviewer_id, remarks=remarks.strip(),
                         reviewed_on=datetime.now().isoformat(timespec="minutes"))
                self.store.write("submissions", items)
                return s
        raise ValueError("Request not found")

    def withdraw(self, sub_id: str, user_id: str) -> dict:
        items = self._all()
        for s in items:
            if s["id"] == sub_id and s["user_id"] == user_id:
                if s["status"] != "Pending":
                    raise ValueError("Only pending requests can be withdrawn")
                s["status"] = "Withdrawn"
                self.store.write("submissions", items)
                return s
        raise ValueError("Request not found")
