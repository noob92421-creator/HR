"""Jinja filters and globals shared by every template."""
from __future__ import annotations

from datetime import date, datetime

from flask import Flask, current_app, g

from .registry import COLORS, get_registry
from .security import csrf_token

STATUS_STYLES = {
    "Pending": ("amber", "bi-hourglass-split"),
    "Approved": ("emerald", "bi-check-circle-fill"),
    "Rejected": ("coral", "bi-x-circle-fill"),
    "Withdrawn": ("slate", "bi-arrow-counterclockwise"),
    "Draft": ("sky", "bi-pencil"),
}


def _parse(value):
    if isinstance(value, (date, datetime)):
        return value
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return None


def fmt_date(value, fmt: str = "%d %b %Y") -> str:
    d = _parse(value)
    return d.strftime(fmt) if d else (value or "—")


def fmt_datetime(value) -> str:
    d = _parse(value)
    return d.strftime("%d %b %Y, %I:%M %p") if d else (value or "—")


def time_ago(value) -> str:
    d = _parse(value)
    if not d:
        return ""
    if not isinstance(d, datetime):
        d = datetime.combine(d, datetime.min.time())
    secs = int((datetime.now() - d).total_seconds())
    if secs < 60:
        return "just now"
    for unit, size in (("d", 86400), ("h", 3600), ("m", 60)):
        if secs >= size:
            n = secs // size
            return f"{n}{unit} ago" if unit != "d" or n < 30 else fmt_date(d)
    return ""


def days_fmt(value) -> str:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return str(value)
    return f"{v:g}"


def greeting() -> str:
    h = datetime.now().hour
    return "Good morning" if h < 12 else "Good afternoon" if h < 17 else "Good evening"


def init_templating(app: Flask) -> None:
    app.jinja_env.filters.update(date=fmt_date, datetime=fmt_datetime, ago=time_ago, days=days_fmt)
    app.jinja_env.globals.update(csrf_token=csrf_token, greeting=greeting, STATUS_STYLES=STATUS_STYLES,
                                 COLORS=COLORS)

    @app.context_processor
    def inject_common():
        user = g.get("user")
        ctx = {
            "portal_name": current_app.config["PORTAL_NAME"],
            "company": current_app.config["COMPANY"],
            "current_user": user,
            "active_module": g.get("active_module"),
            "today": date.today(),
        }
        if user is not None:
            from app.services import services
            reg = get_registry()
            nav = reg.for_user(user, nav=True)
            groups: dict[str, list] = {}
            for m in nav:
                groups.setdefault(m.category, []).append(m)
            ctx.update(
                nav_groups=groups,
                unread_notifications=services().org.unread_count(user.id),
                nav_notifications=services().org.notifications(user.id, 6),
            )
        return ctx
