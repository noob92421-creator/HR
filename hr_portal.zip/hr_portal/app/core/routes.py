"""Core pages that every user shares: login, logout, landing page, notifications."""
from __future__ import annotations

from flask import (Blueprint, current_app, flash, g, jsonify, redirect, render_template,
                   request, url_for)

from app.services import services

from .registry import get_registry
from .security import login_required, login_user, logout_user, safe_next

auth_bp = Blueprint("auth", __name__)
main_bp = Blueprint("main", __name__)


# ====================================================================== auth
@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if g.get("user"):
        return redirect(url_for("main.home"))
    login_value = ""
    if request.method == "POST":
        login_value = request.form.get("login", "").strip()
        password = request.form.get("password", "")
        if not login_value or not password:
            flash("Enter your username or email and your password.", "danger")
        else:
            user = services().users.authenticate(login_value, password)
            if user is None:
                flash("That username/email and password don't match an active account.", "danger")
            else:
                login_user(user, remember=bool(request.form.get("remember")))
                flash(f"Welcome back, {user.first_name}!", "success")
                return redirect(safe_next(request.args.get("next"), url_for("main.home")))
    demo = []
    if current_app.config.get("SHOW_DEMO_ACCOUNTS"):
        demo = services().store.read("demo_accounts", [])
    return render_template("auth/login.html", login_value=login_value, demo_accounts=demo)


@auth_bp.route("/logout", methods=["POST"])
def logout():
    logout_user()
    flash("You have been signed out.", "info")
    return redirect(url_for("auth.login"))


# ====================================================================== home
@main_bp.route("/")
@login_required
def home():
    user = g.user
    svc = services()
    reg = get_registry()

    modules = [(m, m.badge_for(user)) for m in reg.for_user(user, home=True)]

    # Profile summary rows are configured in config.PROFILE_SUMMARY_FIELDS
    manager = svc.users.get(user.get("manager_id")) if user.get("manager_id") else None
    record = {**user.to_dict(), "manager_name": manager.name if manager else "—"}
    summary = []
    for label, key, icon in current_app.config["PROFILE_SUMMARY_FIELDS"]:
        value = record.get(key) or "—"
        if key.endswith("_on") and value != "—":
            from .templating import fmt_date
            value = f"{fmt_date(value)} · {user.tenure}"
        summary.append({"label": label, "value": value, "icon": icon})

    # Quick stats — each only appears if the user can use the related module.
    stats = []
    if user.can("leave.view"):
        bal = svc.leaves.balances(user.id)
        avail = sum(b["available"] or 0 for b in bal if b["annual_quota"])
        stats.append({"label": "Leave available", "value": f"{avail:g}", "unit": "days",
                      "icon": "bi-sun", "color": "amber", "href": url_for("leave.index")})
    if user.can("leave_approval.view"):
        users_by_id = {u.id: u for u in svc.users.all()}
        n = svc.leaves.pending_count(user, users_by_id, user.can("leave_approval.all"))
        stats.append({"label": "Awaiting your approval", "value": n, "unit": "requests",
                      "icon": "bi-inbox", "color": "coral", "href": url_for("leave_approval.index")})
    if user.can("forms.view"):
        subs = svc.submissions.for_user(user.id)
        stats.append({"label": "My open applications", "value": sum(s["status"] == "Pending" for s in subs),
                      "unit": "pending", "icon": "bi-file-earmark-text", "color": "violet",
                      "href": url_for("forms.my_requests")})
    team = svc.users.team_of(user.id)
    if team:
        stats.append({"label": "Direct reports", "value": len(team), "unit": "people",
                      "icon": "bi-people", "color": "teal",
                      "href": url_for("directory.index") if user.can("directory.view") else None})

    return render_template(
        "main/home.html",
        modules=modules,
        summary=summary,
        stats=stats,
        announcements=svc.org.announcements(4),
        holidays=svc.org.upcoming_holidays(4),
        notifications=svc.org.notifications(user.id, 5),
    )


# ============================================================= notifications
@main_bp.route("/notifications/read", methods=["POST"])
@login_required
def notifications_read():
    services().org.mark_all_read(g.user.id)
    if request.accept_mimetypes.best == "application/json" or request.is_json:
        return jsonify(ok=True)
    return redirect(safe_next(request.form.get("next"), url_for("main.home")))


@main_bp.route("/notifications.json")
@login_required
def notifications_json():
    items = services().org.notifications(g.user.id, 8)
    return jsonify(items=items, unread=services().org.unread_count(g.user.id))
