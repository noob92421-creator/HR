"""Session login, permission decorators and CSRF protection."""
from __future__ import annotations

import hmac
import secrets
from functools import wraps
from urllib.parse import urlparse

from flask import abort, current_app, g, redirect, request, session, url_for

from app.services import services


# ---------------------------------------------------------------- session user
def load_user():
    """before_request: put the signed-in user (or None) on g.user."""
    g.user = None
    user_id = session.get("user_id")
    if user_id:
        user = services().users.get(user_id)
        if user and user.get("active", True):
            g.user = user
        else:
            session.clear()


def login_user(user, remember: bool = False) -> None:
    session.clear()
    session["user_id"] = user.id
    session.permanent = remember
    session["_csrf"] = secrets.token_urlsafe(32)


def logout_user() -> None:
    session.clear()


def safe_next(target: str | None, fallback: str) -> str:
    """Only allow redirects to paths on this site."""
    if not target:
        return fallback
    parsed = urlparse(target)
    if parsed.scheme or parsed.netloc or not target.startswith("/"):
        return fallback
    return target


# ---------------------------------------------------------------- decorators
def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if g.get("user") is None:
            return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
        return view(*args, **kwargs)
    return wrapped


def require(*permissions: str):
    """Allow the view if the user holds ANY of the given permissions.

    Module entry permissions are enforced automatically by the registry; use
    this for finer actions inside a module, e.g. @require("forms.review").
    """
    def deco(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = g.get("user")
            if user is None:
                return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
            if not user.can_any(*permissions):
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return deco


# ---------------------------------------------------------------- CSRF
def csrf_token() -> str:
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(32)
    return session["_csrf"]


def csrf_protect():
    """before_request: every state-changing request must carry the token."""
    if not current_app.config.get("CSRF_ENABLED", True):
        return None
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return None
    sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token", "")
    if not sent or not hmac.compare_digest(sent, session.get("_csrf", "")):
        abort(400, description="Your session expired or the form was tampered with. Reload the page and try again.")
    return None
