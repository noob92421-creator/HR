"""Plug-and-play module registry.

Every feature of the portal (Dashboard, Forms, Leave Approval, ...) is a
self-contained package inside ``app/modules/``. A package becomes a module
simply by exposing a ``MODULE`` object in its ``module.py``::

    # app/modules/payslips/module.py
    from app.core.registry import PortalModule
    from .routes import bp

    MODULE = PortalModule(
        key="payslips",
        name="Payslips",
        description="Download monthly salary slips.",
        icon="bi-receipt",
        color="amber",
        permission="payslips.view",
        blueprint=bp,
    )

At start-up the registry imports every package, registers its blueprint
under ``/m/<key>`` and protects all of its routes (see ``guard``): the user must be signed in
and must hold ``MODULE.permission``. The home page then shows one card per
module the user can open. Nothing else in the code base needs to change.

Packages whose name starts with an underscore (e.g. ``_template_module``)
are skipped, so they can serve as copy-paste starters.
"""
from __future__ import annotations

import importlib
import pkgutil
from dataclasses import dataclass, field
from typing import Callable, Optional

from flask import Blueprint, Flask, abort, current_app, g, redirect, request, url_for


# Named colour tokens that map to gradients in static/css/portal.css.
COLORS = ("indigo", "violet", "pink", "coral", "amber", "emerald", "teal", "sky", "blue", "slate")


@dataclass
class PortalModule:
    key: str                         # unique slug; also the URL prefix /m/<key>
    name: str                        # card / sidebar title
    description: str                 # one-line summary on the card
    icon: str                        # Bootstrap Icons class, e.g. "bi-speedometer2"
    blueprint: Blueprint
    permission: str                  # permission needed to see/open the module
    color: str = "indigo"            # one of COLORS
    order: int = 100                 # sort order on home page & sidebar
    category: str = "Workspace"      # sidebar group heading
    # Extra permissions the module understands (shown in the Admin matrix).
    permissions: dict[str, str] = field(default_factory=dict)
    # Optional callable(user) -> dict | None, e.g. {"value": 3, "label": "pending"}
    # displayed as a small badge on the module card.
    badge: Optional[Callable] = None
    show_on_home: bool = True
    show_in_nav: bool = True
    endpoint: str = "index"          # view function name used as the entry point

    def __post_init__(self):
        if self.color not in COLORS:
            raise ValueError(f"Module '{self.key}': unknown color '{self.color}'. Use one of {COLORS}.")
        # The entry permission always appears in the permission list.
        self.permissions = {self.permission: f"Open {self.name}", **self.permissions}

    @property
    def url(self) -> str:
        return url_for(f"{self.blueprint.name}.{self.endpoint}")

    def badge_for(self, user):
        if not self.badge:
            return None
        try:
            return self.badge(user)
        except Exception:  # a broken badge must never break the home page
            current_app.logger.exception("Badge for module %s failed", self.key)
            return None


class ModuleRegistry:
    def __init__(self):
        self._modules: dict[str, PortalModule] = {}
        self._by_blueprint: dict[str, PortalModule] = {}

    # ------------------------------------------------------------------ setup
    def init_app(self, app: Flask, package: str = "app.modules"):
        disabled = set(app.config.get("DISABLED_MODULES", []))
        pkg = importlib.import_module(package)
        for info in sorted(pkgutil.iter_modules(pkg.__path__), key=lambda i: i.name):
            if not info.ispkg or info.name.startswith("_"):
                continue
            try:
                mod = importlib.import_module(f"{package}.{info.name}.module")
            except ModuleNotFoundError as exc:
                if exc.name == f"{package}.{info.name}.module":
                    app.logger.warning("Skipping %s: no module.py", info.name)
                    continue
                raise
            module: PortalModule | None = getattr(mod, "MODULE", None)
            if module is None:
                app.logger.warning("Skipping %s: module.py defines no MODULE", info.name)
                continue
            if module.key in disabled:
                continue
            self.register(app, module)
        app.before_request(self.guard)
        app.extensions["module_registry"] = self

    def register(self, app: Flask, module: PortalModule):
        if module.key in self._modules:
            raise RuntimeError(f"Duplicate module key '{module.key}'")
        app.register_blueprint(module.blueprint, url_prefix=f"/m/{module.key}")
        self._modules[module.key] = module
        self._by_blueprint[module.blueprint.name] = module

    def guard(self):
        """App-level before_request hook: protects every module route."""
        if not request.blueprint:
            return None
        module = self._by_blueprint.get(request.blueprint.split(".")[0])
        if module is None:
            return None
        user = g.get("user")
        if user is None:
            return redirect(url_for("auth.login", next=request.full_path.rstrip("?")))
        if not user.can(module.permission):
            abort(403)
        g.active_module = module
        return None

    # ---------------------------------------------------------------- queries
    def all(self) -> list[PortalModule]:
        return sorted(self._modules.values(), key=lambda m: (m.order, m.name))

    def get(self, key: str) -> PortalModule | None:
        return self._modules.get(key)

    def for_user(self, user, *, home: bool = False, nav: bool = False) -> list[PortalModule]:
        mods = [m for m in self.all() if user and user.can(m.permission)]
        if home:
            mods = [m for m in mods if m.show_on_home]
        if nav:
            mods = [m for m in mods if m.show_in_nav]
        return mods

    def all_permissions(self) -> list[tuple[PortalModule, dict[str, str]]]:
        return [(m, m.permissions) for m in self.all()]


def get_registry() -> ModuleRegistry:
    """The registry of the running app."""
    return current_app.extensions["module_registry"]
