from __future__ import annotations

from flask import Blueprint, abort, g, render_template, request

from app.services import services

bp = Blueprint("directory", __name__, template_folder="templates")


@bp.route("/")
def index():
    svc = services()
    q = request.args.get("q", "").strip().lower()
    dept = request.args.get("dept", "")
    loc = request.args.get("loc", "")
    people = svc.users.all(include_inactive=False)
    locations = sorted({u.location.split(",")[0] for u in people})
    if q:
        people = [u for u in people if q in " ".join(
            [u.name, u.designation, u.emp_id, u.email, " ".join(u.get("skills", []))]).lower()]
    if dept:
        people = [u for u in people if u.department == dept]
    if loc:
        people = [u for u in people if u.location.startswith(loc)]
    users = {u.id: u for u in svc.users.all()}
    return render_template("directory/index.html", people=sorted(people, key=lambda u: u.name),
                           departments=svc.users.departments(), locations=locations, q=q, dept=dept, loc=loc,
                           users=users, sensitive=g.user.can("directory.sensitive"))


@bp.route("/<user_id>")
def person(user_id):
    svc = services()
    u = svc.users.get(user_id)
    if not u or not u.get("active", True):
        abort(404)
    manager = svc.users.get(u.manager_id) if u.get("manager_id") else None
    return render_template("directory/person.html", person=u, manager=manager, reports=svc.users.team_of(u.id),
                           sensitive=g.user.can("directory.sensitive") or g.user.id == u.id)
