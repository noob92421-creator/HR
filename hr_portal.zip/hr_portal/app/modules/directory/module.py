from app.core.registry import PortalModule

from .routes import bp

MODULE = PortalModule(
    key="directory",
    name="People Directory",
    description="Find colleagues by name, team, skill or location, and see who reports to whom.",
    icon="bi-person-lines-fill",
    color="sky",
    permission="directory.view",
    permissions={"directory.sensitive": "See personal details (phone, blood group, emergency contact)"},
    blueprint=bp,
    order=50,
    category="Workspace",
)
