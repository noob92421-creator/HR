from app.core.registry import PortalModule
from app.services import services

from .routes import bp


def _badge(user):
    users = {u.id: u for u in services().users.all()}
    n = services().leaves.pending_count(user, users, user.can("leave_approval.all"))
    return {"value": n, "label": "pending"} if n else None


MODULE = PortalModule(
    key="leave_approval",
    name="Leave Approval",
    description="Review, approve or reject your team's leave requests, one by one or in bulk.",
    icon="bi-calendar2-check",
    color="emerald",
    permission="leave_approval.view",
    permissions={"leave_approval.all": "See and act on everyone's requests (not only direct reports)"},
    blueprint=bp,
    order=40,
    category="Manage",
    badge=_badge,
)
