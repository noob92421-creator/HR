from __future__ import annotations

from datetime import date, timedelta

from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from app.services import LeaveError, services

bp = Blueprint("leave_approval", __name__, template_folder="templates")


def _queue(status=None):
    svc = services()
    users = {u.id: u for u in svc.users.all()}
    return svc.leaves.queue(g.user, users, include_all=g.user.can("leave_approval.all"), status=status), users


@bp.route("/")
def index():
    svc = services()
    tab = request.args.get("tab", "Pending")
    q = request.args.get("q", "").strip().lower()
    items, users = _queue(None if tab == "All" else tab)
    if q:
        items = [i for i in items if q in i["employee"].name.lower() or q in i["id"].lower()]
    all_items, _ = _queue()
    counts = {s: sum(i["status"] == s for i in all_items) for s in ("Pending", "Approved", "Rejected")}
    counts["All"] = len(all_items)

    # who is away in the next 7 days (approved + pending) — helps the approver plan
    today = date.today()
    week_end = today + timedelta(days=7)
    away = [i for i in all_items if i["status"] in ("Approved", "Pending")
            and i["from_date"] <= week_end.isoformat() and i["to_date"] >= today.isoformat()]
    balances = {i["user_id"]: {b["code"]: b for b in svc.leaves.balances(i["user_id"])} for i in items}
    return render_template("leave_approval/index.html", items=items, tab=tab, counts=counts, q=q,
                           away=sorted(away, key=lambda i: i["from_date"]), users=users, balances=balances,
                           policy={t["code"]: t for t in svc.leaves.policy()},
                           scope="Everyone" if g.user.can("leave_approval.all") else "My team")


def _decide_one(leave_id, decision, remarks):
    svc = services()
    rec = svc.leaves.decide(leave_id, g.user, decision, remarks)
    svc.org.notify(rec["user_id"], f"Your leave {leave_id} was {decision.lower()} by {g.user.name}",
                   url_for("leave.index"), "bi-check-circle" if decision == "Approved" else "bi-x-circle")
    return rec


def _allowed(leave_id) -> bool:
    items, _ = _queue()
    return any(i["id"] == leave_id for i in items)


@bp.route("/<leave_id>/decide", methods=["POST"])
def decide(leave_id):
    if not _allowed(leave_id):
        flash("You can't act on that request.", "danger")
    else:
        try:
            decision = request.form.get("decision", "")
            _decide_one(leave_id, decision, request.form.get("remarks", ""))
            flash(f"{leave_id} {decision.lower()}.", "success")
        except LeaveError as exc:
            flash(str(exc), "danger")
    return redirect(url_for(".index", tab=request.form.get("tab", "Pending")))


@bp.route("/bulk", methods=["POST"])
def bulk():
    ids = request.form.getlist("ids")
    if not ids:
        flash("Select at least one request.", "warning")
        return redirect(url_for(".index"))
    done, failed = 0, []
    for leave_id in ids:
        try:
            if not _allowed(leave_id):
                raise LeaveError("not allowed")
            _decide_one(leave_id, "Approved", request.form.get("remarks", ""))
            done += 1
        except LeaveError:
            failed.append(leave_id)
    if done:
        flash(f"Approved {done} request(s).", "success")
    if failed:
        flash(f"Couldn't approve: {', '.join(failed)}.", "danger")
    return redirect(url_for(".index"))
