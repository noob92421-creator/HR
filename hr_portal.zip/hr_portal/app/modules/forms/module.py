from app.core.registry import PortalModule
from app.services import services

from .routes import bp


def _badge(user):
    if user.can("forms.review"):
        n = len(services().submissions.all("Pending"))
        return {"value": n, "label": "to review"} if n else None
    n = sum(s["status"] == "Pending" for s in services().submissions.for_user(user.id))
    return {"value": n, "label": "in progress"} if n else None


MODULE = PortalModule(
    key="forms",
    name="Forms & Applications",
    description="Access cards, certificates, NOCs, travel, claims — auto-filled and ready to submit.",
    icon="bi-ui-checks-grid",
    color="violet",
    permission="forms.view",
    permissions={"forms.review": "Review & approve submitted applications"},
    blueprint=bp,
    order=20,
    category="Requests",
    badge=_badge,
)
