"""Forms engine: YAML definitions -> web form -> personalised application letter.

Each ``definitions/*.yaml`` file describes one form type:

* metadata (title, category, icon, colour, short description, approver ...)
* ``common:`` which shared fields to include (name, emp_id, designation, date ...),
  defined once in ``common_fields.yaml`` and auto-filled from the user's profile
* ``fields:`` the fields specific to this form
* ``letter:`` the predefined application format. ``{{ placeholders }}`` are
  replaced with the person's answers, producing their personalised application.

Adding a new form = dropping a new YAML file in ``definitions/``. The library
reloads files when they change, so no restart is needed.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any, Optional

import yaml
from jinja2 import StrictUndefined, TemplateError
from jinja2.sandbox import SandboxedEnvironment
from markupsafe import Markup, escape

FIELD_TYPES = {"text", "textarea", "email", "tel", "number", "date", "time",
               "select", "radio", "checkbox", "file", "section"}
WIDTHS = {"full": "col-12", "half": "col-md-6", "third": "col-md-4", "quarter": "col-md-3", "twothirds": "col-md-8"}
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^\+?[0-9 ()-]{7,20}$")


# ============================================================ definitions
@dataclass
class FieldDef:
    name: str
    label: str
    type: str = "text"
    required: bool = False
    options: list[str] = field(default_factory=list)
    placeholder: str = ""
    help: str = ""
    default: Any = None
    prefill: Optional[str] = None      # user attribute (or "today") to pre-fill from
    readonly: bool = False
    width: str = "half"
    min: Any = None                    # number or date ("today", "+7" = today + 7 days)
    max: Any = None
    maxlength: Optional[int] = None
    pattern: Optional[str] = None      # regex the value must match
    pattern_message: str = ""
    rows: int = 3
    show_if: Optional[dict] = None     # {"field": x, "equals": v} | {"field": x, "in": [..]} | {"field": x, "contains": v}
    accept: str = ""                   # file inputs
    common: bool = False               # came from common_fields.yaml

    def __post_init__(self):
        if self.type not in FIELD_TYPES:
            raise ValueError(f"Field '{self.name}': unknown type '{self.type}'")
        if self.type in ("select", "radio", "checkbox") and not self.options:
            raise ValueError(f"Field '{self.name}': '{self.type}' needs options")
        self.options = [str(o) for o in self.options]

    @property
    def col_class(self) -> str:
        return WIDTHS.get(self.width, "col-md-6")

    @property
    def is_multi(self) -> bool:
        return self.type == "checkbox"

    def resolved_bound(self, which: str) -> Optional[str]:
        """min/max as a string usable in HTML (dates support 'today' and '+N')."""
        val = getattr(self, which)
        if val is None:
            return None
        if self.type == "date":
            return _resolve_date(val).isoformat()
        return str(val)


@dataclass
class FormDef:
    id: str
    title: str
    description: str
    category: str
    fields: list[FieldDef]
    letter: dict
    icon: str = "bi-file-earmark-text"
    color: str = "indigo"
    approver: str = "HR Department"
    turnaround: str = ""
    instructions: list[str] = field(default_factory=list)
    permission: Optional[str] = None   # extra permission needed to see this form
    tags: list[str] = field(default_factory=list)
    source: str = ""

    @property
    def input_fields(self) -> list[FieldDef]:
        return [f for f in self.fields if f.type != "section"]

    def field(self, name: str) -> Optional[FieldDef]:
        return next((f for f in self.input_fields if f.name == name), None)

    @property
    def common_fields(self) -> list[FieldDef]:
        return [f for f in self.fields if f.common]

    @property
    def specific_fields(self) -> list[FieldDef]:
        return [f for f in self.fields if not f.common]


def _resolve_date(val) -> date:
    if isinstance(val, date):
        return val
    s = str(val).strip()
    if s == "today":
        return date.today()
    if re.fullmatch(r"[+-]\d+", s):
        from datetime import timedelta
        return date.today() + timedelta(days=int(s))
    return date.fromisoformat(s)


# ============================================================ library
class FormLibrary:
    def __init__(self, directory: Path):
        self.directory = Path(directory)
        self._cache: dict[str, FormDef] = {}
        self._stamp: tuple = ()
        self.errors: dict[str, str] = {}

    def _current_stamp(self) -> tuple:
        files = sorted(self.directory.glob("*.y*ml")) + [self.directory.parent / "common_fields.yaml"]
        return tuple((str(p), p.stat().st_mtime) for p in files if p.exists())

    def _load(self) -> None:
        stamp = self._current_stamp()
        if stamp == self._stamp:
            return
        common_path = self.directory.parent / "common_fields.yaml"
        common = yaml.safe_load(common_path.read_text(encoding="utf-8")) if common_path.exists() else {}
        forms, errors = {}, {}
        for path in sorted(self.directory.glob("*.y*ml")):
            if path.name.startswith("_"):
                continue
            try:
                fd = self._parse(yaml.safe_load(path.read_text(encoding="utf-8")), common, path.name)
                if fd.id in forms:
                    raise ValueError(f"duplicate form id '{fd.id}'")
                forms[fd.id] = fd
            except Exception as exc:  # a broken file must not take the portal down
                errors[path.name] = str(exc)
        self._cache, self.errors, self._stamp = forms, errors, stamp

    @staticmethod
    def _parse(raw: dict, common: dict, source: str) -> FormDef:
        if not isinstance(raw, dict):
            raise ValueError("file must contain a mapping")
        for key in ("id", "title", "description", "category", "letter"):
            if key not in raw:
                raise ValueError(f"missing '{key}'")
        fields: list[FieldDef] = []
        if raw.get("common"):
            fields.append(FieldDef(name="_common", label="Your details", type="section",
                                   help="Filled in from your profile.", common=True))
        for name in raw.get("common", []):
            if name not in common:
                raise ValueError(f"unknown common field '{name}'")
            fields.append(FieldDef(name=name, common=True, **common[name]))
        for f in raw.get("fields", []):
            fields.append(FieldDef(**f))
        names = [f.name for f in fields if f.type != "section"]
        if len(names) != len(set(names)):
            raise ValueError("field names must be unique")
        letter = raw["letter"]
        for key in ("subject", "body"):
            if key not in letter:
                raise ValueError(f"letter needs '{key}'")
        meta = {k: raw[k] for k in ("icon", "color", "approver", "turnaround", "instructions",
                                    "permission", "tags") if k in raw}
        return FormDef(id=raw["id"], title=raw["title"], description=raw["description"],
                       category=raw["category"], fields=fields, letter=letter, source=source, **meta)

    # ---------------------------------------------------------------- API
    def all(self, user=None) -> list[FormDef]:
        self._load()
        forms = sorted(self._cache.values(), key=lambda f: (f.category, f.title))
        if user is not None:
            forms = [f for f in forms if not f.permission or user.can(f.permission)]
        return forms

    def get(self, form_id: str) -> Optional[FormDef]:
        self._load()
        return self._cache.get(form_id)

    def categories(self, user=None) -> list[str]:
        return sorted({f.category for f in self.all(user)})


# ============================================================ values
def prefill(form: FormDef, user_record: dict) -> dict:
    values = {}
    for f in form.input_fields:
        if f.prefill == "today":
            values[f.name] = date.today().isoformat()
        elif f.prefill:
            values[f.name] = user_record.get(f.prefill, "") or ""
        elif f.default is not None:
            values[f.name] = list(f.default) if f.is_multi else str(f.default)
        else:
            values[f.name] = [] if f.is_multi else ""
    return values


def is_visible(f: FieldDef, values: dict) -> bool:
    rule = f.show_if
    if not rule:
        return True
    other = values.get(rule["field"])
    if "equals" in rule:
        return other == rule["equals"]
    if "in" in rule:
        return other in rule["in"]
    if "contains" in rule:
        return isinstance(other, list) and rule["contains"] in other
    if "not_empty" in rule:
        return bool(other)
    return True


def collect(form: FormDef, formdata, user_record: dict) -> dict:
    """Read posted values; read-only profile fields always come from the profile."""
    base = prefill(form, user_record)
    values = {}
    for f in form.input_fields:
        if f.readonly and f.prefill:
            values[f.name] = base[f.name]
        elif f.is_multi:
            values[f.name] = [v for v in formdata.getlist(f.name) if v]
        elif f.type == "file":
            values[f.name] = formdata.get(f.name + "__name", "") or formdata.get(f.name, "")
        else:
            values[f.name] = (formdata.get(f.name) or "").strip()
    return values


def validate(form: FormDef, values: dict) -> dict[str, str]:
    errors: dict[str, str] = {}
    for f in form.input_fields:
        if not is_visible(f, values):
            continue
        v = values.get(f.name)
        empty = v in ("", None, [])
        if empty:
            if f.required:
                errors[f.name] = f"{f.label} is required."
            continue
        if f.type == "email" and not EMAIL_RE.match(v):
            errors[f.name] = "Enter a valid email address."
        elif f.type == "tel" and not PHONE_RE.match(v):
            errors[f.name] = "Enter a valid phone number."
        elif f.type in ("select", "radio") and v not in f.options:
            errors[f.name] = "Choose one of the listed options."
        elif f.type == "checkbox" and any(x not in f.options for x in v):
            errors[f.name] = "Choose from the listed options."
        elif f.type == "number":
            try:
                n = float(v)
                if f.min is not None and n < float(f.min):
                    errors[f.name] = f"Must be at least {f.min}."
                elif f.max is not None and n > float(f.max):
                    errors[f.name] = f"Must be at most {f.max}."
            except ValueError:
                errors[f.name] = "Enter a number."
        elif f.type == "date":
            try:
                d = date.fromisoformat(v)
                if f.min is not None and d < _resolve_date(f.min):
                    errors[f.name] = f"Date can't be before {_resolve_date(f.min):%d %b %Y}."
                elif f.max is not None and d > _resolve_date(f.max):
                    errors[f.name] = f"Date can't be after {_resolve_date(f.max):%d %b %Y}."
            except ValueError:
                errors[f.name] = "Enter a valid date."
        if f.name not in errors and f.maxlength and isinstance(v, str) and len(v) > f.maxlength:
            errors[f.name] = f"Keep it under {f.maxlength} characters."
        if f.name not in errors and f.pattern and isinstance(v, str) and not re.fullmatch(f.pattern, v):
            errors[f.name] = f.pattern_message or "The format isn't right."
    # cross-field rule: any field named *_to / return_date must not precede its start
    for start, end in (("from_date", "to_date"), ("depart_date", "return_date")):
        a, b = values.get(start), values.get(end)
        if a and b and start not in errors and end not in errors and b < a:
            errors[end] = "Must be on or after the start date."
    return errors


# ============================================================ letter
def _fmt_date(value, fmt="%d %B %Y"):
    if isinstance(value, Markup):
        return value
    try:
        return date.fromisoformat(str(value)).strftime(fmt)
    except ValueError:
        return value


def _money(value):
    """Format as Indian rupees with lakh grouping: 1234567 -> ₹12,34,567.00"""
    if isinstance(value, Markup):
        return value
    try:
        n = float(value)
    except (TypeError, ValueError):
        return value
    whole, frac = f"{abs(n):.2f}".split(".")
    head, tail = whole[:-3], whole[-3:]
    groups = []
    while len(head) > 2:
        groups.insert(0, head[-2:])
        head = head[:-2]
    if head:
        groups.insert(0, head)
    sign = "-" if n < 0 else ""
    return f"{sign}₹{','.join(groups + [tail])}.{frac}"


def _join_list(value, sep=", "):
    if isinstance(value, (list, tuple)):
        items = [str(v) for v in value]
        if len(items) > 1 and sep == "and":
            return ", ".join(items[:-1]) + " and " + items[-1]
        return (", " if sep == "and" else sep).join(items)
    return value


_env = SandboxedEnvironment(autoescape=True, undefined=StrictUndefined, trim_blocks=True, lstrip_blocks=True)
_env.filters.update(date=_fmt_date, money=_money, listing=_join_list)


def render_letter(form: FormDef, values: dict, user_record: dict, company: dict,
                  preview: bool = False) -> dict:
    """Return the personalised letter parts as safe HTML.

    In preview mode, blank answers are shown as highlighted placeholders so the
    person sees where their input will go.
    """
    ctx: dict[str, Any] = {}
    for f in form.input_fields:
        v = values.get(f.name, "")
        visible = is_visible(f, values)
        if preview and visible and v in ("", None, []):
            ctx[f.name] = Markup('<span class="ph">%s</span>') % f.label
        elif not visible:
            ctx[f.name] = [] if f.is_multi else ""
        else:
            ctx[f.name] = v
    ctx.update(user=user_record, company=company, form={"title": form.title, "approver": form.approver},
               today=date.today().isoformat())

    def part(key: str, paragraphs: bool = False) -> Markup:
        src = form.letter.get(key)
        if not src:
            return Markup("")
        try:
            text = _env.from_string(str(src)).render(ctx)
        except TemplateError as exc:
            return Markup('<span class="text-danger">[Template error in %s: %s]</span>') % (key, exc)
        if paragraphs:
            blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
            return Markup("").join(Markup("<p>%s</p>") % Markup(b.replace("\n", "<br>")) for b in blocks)
        return Markup(text.strip().replace("\n", "<br>"))

    return {
        "to": part("to") or Markup(escape(form.approver)),
        "subject": part("subject"),
        "salutation": part("salutation") or Markup("Respected Sir/Madam,"),
        "body": part("body", paragraphs=True),
        "closing": part("closing") or Markup("Yours sincerely,"),
        "annexure": part("annexure", paragraphs=True),
        "date": _fmt_date(values.get("date") or date.today().isoformat()),
        "place": (user_record.get("location") or "").split(",")[0],
        "signatory": {
            "name": values.get("name") or user_record.get("name"),
            "designation": values.get("designation") or user_record.get("designation"),
            "emp_id": values.get("emp_id") or user_record.get("emp_id"),
            "department": values.get("department") or user_record.get("department"),
        },
    }
