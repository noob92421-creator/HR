"""Forms module: catalogue, fill-in with live letter preview, my applications, HR review."""
from __future__ import annotations

from flask import (Blueprint, abort, current_app, flash, g, jsonify, redirect, render_template,
                   request, url_for)

from app.core.security import require
from app.services import services

from .engine import FormLibrary, collect, is_visible, prefill, render_letter, validate

bp = Blueprint("forms", __name__, template_folder="templates")


def library() -> FormLibrary:
    lib = current_app.extensions.get("form_library")
    if lib is None:
        lib = current_app.extensions["form_library"] = FormLibrary(current_app.config["FORMS_DIR"])
    return lib


def _get_form(form_id: str):
    form = library().get(form_id)
    if form is None or (form.permission and not g.user.can(form.permission)):
        abort(404)
    return form


def _profile():
    return services().users.profile_record(g.user)


# ------------------------------------------------------------------ catalogue
@bp.route("/")
def index():
    lib = library()
    forms = lib.all(g.user)
    mine = services().submissions.for_user(g.user.id)
    counts = {}
    for s in mine:
        counts[s["form_id"]] = counts.get(s["form_id"], 0) + 1
    return render_template("forms/index.html", forms=forms, categories=lib.categories(g.user),
                           counts=counts, load_errors=lib.errors if g.user.can("admin.view") else {})


# ------------------------------------------------------------------ fill in
@bp.route("/<form_id>", methods=["GET", "POST"])
def fill(form_id):
    form = _get_form(form_id)
    profile = _profile()
    step = "edit"
    errors: dict = {}
    if request.method == "POST":
        values = collect(form, request.form, profile)
        errors = validate(form, values)
        action = request.form.get("action", "review")
        if errors:
            flash("Please fix the highlighted fields.", "danger")
        elif action == "submit":
            letter = render_letter(form, values, profile, current_app.config["COMPANY"])
            letter_html = render_template("forms/_letter.html", letter=letter, form=form, standalone=False)
            clean = {f.name: values[f.name] for f in form.input_fields if is_visible(f, values)}
            sub = services().submissions.create(g.user.id, form.id, form.title, clean, letter_html)
            _notify_reviewers(form, sub)
            flash(f"Your {form.title} has been submitted as {sub['id']}.", "success")
            return redirect(url_for(".request_detail", sub_id=sub["id"], submitted=1))
        elif action == "review":
            step = "review"
    else:
        values = prefill(form, profile)
    letter = render_letter(form, values, profile, current_app.config["COMPANY"], preview=(step == "edit"))
    return render_template("forms/fill.html", form=form, values=values, errors=errors, step=step,
                           letter=letter, is_visible=is_visible)


@bp.route("/<form_id>/preview", methods=["POST"])
def preview(form_id):
    """Live preview: re-renders the letter as the user types (called by fetch)."""
    form = _get_form(form_id)
    profile = _profile()
    values = collect(form, request.form, profile)
    letter = render_letter(form, values, profile, current_app.config["COMPANY"], preview=True)
    return jsonify(html=render_template("forms/_letter.html", letter=letter, form=form, standalone=False),
                   visible={f.name: is_visible(f, values) for f in form.input_fields})


def _notify_reviewers(form, sub):
    org = services().org
    for u in services().users.all(include_inactive=False):
        if u.id != g.user.id and u.can("forms.review") and "*" not in u.permissions:
            org.notify(u.id, f"{g.user.name} submitted a {form.title} ({sub['id']})",
                       url_for(".review_detail", sub_id=sub["id"]), "bi-file-earmark-text")


# ------------------------------------------------------------------ my applications
@bp.route("/requests")
def my_requests():
    status = request.args.get("status") or None
    items = services().submissions.for_user(g.user.id)
    if status:
        items = [s for s in items if s["status"] == status]
    return render_template("forms/my_requests.html", items=items, status=status)


@bp.route("/requests/<sub_id>")
def request_detail(sub_id):
    sub = services().submissions.get(sub_id)
    if not sub or (sub["user_id"] != g.user.id and not g.user.can("forms.review")):
        abort(404)
    return _detail(sub, review=False)


@bp.route("/requests/<sub_id>/withdraw", methods=["POST"])
def withdraw(sub_id):
    try:
        services().submissions.withdraw(sub_id, g.user.id)
        flash(f"{sub_id} withdrawn.", "info")
    except ValueError as exc:
        flash(str(exc), "danger")
    return redirect(url_for(".request_detail", sub_id=sub_id))


@bp.route("/requests/<sub_id>/print")
def print_letter(sub_id):
    sub = services().submissions.get(sub_id)
    if not sub or (sub["user_id"] != g.user.id and not g.user.can("forms.review")):
        abort(404)
    form = library().get(sub["form_id"])
    owner = services().users.get(sub["user_id"])
    reviewer = services().users.get(sub["reviewed_by"]) if sub.get("reviewed_by") else None
    letter = render_letter(form, sub["values"], services().users.profile_record(owner),
                           current_app.config["COMPANY"]) if form and owner else None
    return render_template("forms/print.html", sub=sub, form=form, letter=letter, reviewer=reviewer)


# ------------------------------------------------------------------ HR review
@bp.route("/review")
@require("forms.review")
def review():
    status = request.args.get("status", "Pending")
    form_id = request.args.get("form") or None
    items = services().submissions.all(None if status == "All" else status)
    if form_id:
        items = [s for s in items if s["form_id"] == form_id]
    users = {u.id: u for u in services().users.all()}
    return render_template("forms/review.html", items=items, users=users, status=status,
                           form_id=form_id, forms=library().all())


@bp.route("/review/<sub_id>", methods=["GET", "POST"])
@require("forms.review")
def review_detail(sub_id):
    sub = services().submissions.get(sub_id)
    if not sub:
        abort(404)
    if request.method == "POST":
        decision = request.form.get("decision")
        remarks = request.form.get("remarks", "")
        if decision == "Rejected" and not remarks.strip():
            flash("Add a remark so the employee knows why it was rejected.", "danger")
        elif sub["user_id"] == g.user.id:
            flash("You can't review your own application.", "danger")
        else:
            try:
                services().submissions.decide(sub_id, g.user.id, decision, remarks)
                services().org.notify(sub["user_id"], f"Your {sub['form_title']} ({sub_id}) was {decision.lower()}",
                                      url_for(".request_detail", sub_id=sub_id),
                                      "bi-check-circle" if decision == "Approved" else "bi-x-circle")
                flash(f"{sub_id} {decision.lower()}.", "success")
                return redirect(url_for(".review"))
            except ValueError as exc:
                flash(str(exc), "danger")
        sub = services().submissions.get(sub_id)
    return _detail(sub, review=True)


def _detail(sub, review: bool):
    form = library().get(sub["form_id"])
    users = services().users
    owner = users.get(sub["user_id"])
    reviewer = users.get(sub["reviewed_by"]) if sub.get("reviewed_by") else None
    labels = {f.name: f.label for f in form.input_fields} if form else {}
    # Re-render from the stored answers so the office-use stamp shows the live status.
    # (sub["letter_html"] keeps the exact snapshot taken at submission time.)
    letter = None
    if form and owner:
        letter = render_letter(form, sub["values"], users.profile_record(owner), current_app.config["COMPANY"])
    return render_template("forms/detail.html", sub=sub, form=form, owner=owner, reviewer=reviewer,
                           labels=labels, review=review, letter=letter)
