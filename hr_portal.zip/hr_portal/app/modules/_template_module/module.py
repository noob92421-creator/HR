"""STARTER — copy this folder to add a new feature to the portal.

1. Copy  app/modules/_template_module  ->  app/modules/payslips   (no leading underscore)
2. Rename the key/blueprint/template folder from "sample" to "payslips".
3. Edit the MODULE fields below (name, description, icon, colour, permission).
4. Grant the permission to a role: Administration -> Roles & permissions.

Restart the server — a card appears on the home page for everyone whose role
has the permission, a link appears in the sidebar, and every route in the
blueprint is automatically login- and permission-protected.
"""
from app.core.registry import PortalModule

from .routes import bp

MODULE = PortalModule(
    key="sample",                           # URL becomes /m/sample/
    name="Sample Module",
    description="One line that tells people what they can do here.",
    icon="bi-stars",                        # any Bootstrap Icons class: https://icons.getbootstrap.com
    color="teal",                           # indigo violet pink coral amber emerald teal sky blue slate
    permission="sample.view",               # who can see the card and open the module
    permissions={"sample.manage": "Optional finer permission used inside the module"},
    blueprint=bp,
    order=60,                               # position on home page & sidebar
    category="Workspace",                   # sidebar group
    badge=None,                             # or lambda user: {"value": 3, "label": "new"}
)
