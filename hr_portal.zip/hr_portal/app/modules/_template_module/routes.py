from flask import Blueprint, g, render_template

from app.core.security import require

bp = Blueprint("sample", __name__, template_folder="templates")


@bp.route("/")
def index():
    # g.user is the signed-in user; the registry already checked "sample.view".
    return render_template("sample/index.html", items=[])


@bp.route("/manage")
@require("sample.manage")          # finer-grained check inside a module
def manage():
    return render_template("sample/index.html", items=[], managing=True)
