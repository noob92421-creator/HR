from __future__ import annotations

from datetime import date

from flask import Blueprint, flash, g, jsonify, redirect, render_template, request, url_for

from app.services import LeaveError, services

bp = Blueprint("leave", __name__, template_folder="templates")


@bp.route("/")
def index():
    svc = services()
    status = request.args.get("status") or None
    history = svc.leaves.for_user(g.user.id)
    if status:
        history = [l for l in history if l["status"] == status]
    users = {u.id: u for u in svc.users.all()}
    return render_template(
        "leave/index.html",
        balances=svc.leaves.balances(g.user.id),
        policy={t["code"]: t for t in svc.leaves.policy()},
        history=history,
        status=status,
        users=users,
        holidays=svc.org.upcoming_holidays(6),
        form=request.args,  # lets "Apply again" pre-fill the modal
    )


@bp.route("/apply", methods=["POST"])
def apply():
    svc = services()
    f = request.form
    try:
        rec = svc.leaves.apply(g.user, f.get("type", ""), f.get("from_date", ""), f.get("to_date", ""),
                               f.get("reason", ""), half_day=bool(f.get("half_day")), contact=f.get("contact", ""))
    except LeaveError as exc:
        flash(str(exc), "danger")
        return redirect(url_for(".index", apply=1, **{k: f.get(k, "") for k in ("type", "from_date", "to_date", "reason")}))
    if g.user.get("manager_id"):
        svc.org.notify(g.user.manager_id, f"{g.user.name} applied for {rec['days']:g} day(s) of leave ({rec['id']})",
                       url_for("leave_approval.index"), "bi-calendar-plus")
    flash(f"Leave request {rec['id']} for {rec['days']:g} day(s) sent for approval.", "success")
    return redirect(url_for(".index"))


@bp.route("/<leave_id>/withdraw", methods=["POST"])
def withdraw(leave_id):
    try:
        services().leaves.cancel(leave_id, g.user.id)
        flash(f"{leave_id} withdrawn.", "info")
    except LeaveError as exc:
        flash(str(exc), "danger")
    return redirect(url_for(".index"))


@bp.route("/days")
def days():
    """Working-day counter used by the apply dialog as dates change."""
    try:
        start = date.fromisoformat(request.args.get("from", ""))
        end = date.fromisoformat(request.args.get("to", "") or request.args.get("from", ""))
    except ValueError:
        return jsonify(days=None)
    n = services().leaves.working_days(start, end, request.args.get("half") == "1")
    return jsonify(days=n)
