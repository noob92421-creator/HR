from app.core.registry import PortalModule
from app.services import services

from .routes import bp


def _badge(user):
    bal = services().leaves.balances(user.id)
    avail = sum(b["available"] or 0 for b in bal if b["annual_quota"])
    return {"value": f"{avail:g}", "label": "days left"}


MODULE = PortalModule(
    key="leave",
    name="My Leave",
    description="Check balances, apply for leave and track the status of your requests.",
    icon="bi-calendar2-heart",
    color="amber",
    permission="leave.view",
    blueprint=bp,
    order=30,
    category="Requests",
    badge=_badge,
)
