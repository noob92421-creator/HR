from __future__ import annotations

from collections import Counter
from datetime import date

from flask import Blueprint, g, render_template

from app.services import services

bp = Blueprint("dashboard", __name__, template_folder="templates")


@bp.route("/")
def index():
    svc = services()
    org_scope = g.user.can("dashboard.org")
    everyone = svc.users.all(include_inactive=False)
    if org_scope:
        people = everyone
        scope = "Organisation"
    else:
        # managers see their reporting line (direct + indirect reports)
        by_mgr: dict[str, list] = {}
        for u in everyone:
            by_mgr.setdefault(u.get("manager_id"), []).append(u)
        people, stack = [], [g.user.id]
        while stack:
            for u in by_mgr.get(stack.pop(), []):
                people.append(u)
                stack.append(u.id)
        scope = "My team"
    ids = {u.id for u in people}
    leaves = [l for uid in ids for l in svc.leaves.for_user(uid)]
    policy = {t["code"]: t for t in svc.leaves.policy()}
    today = date.today().isoformat()
    year = str(date.today().year)

    on_leave_today = [l for l in leaves if l["status"] == "Approved" and l["from_date"] <= today <= l["to_date"]]
    pending = [l for l in leaves if l["status"] == "Pending"]
    approved_year = [l for l in leaves if l["status"] == "Approved" and l["from_date"].startswith(year)]

    by_dept = Counter(u.department for u in people)
    by_mode = Counter(u.get("work_mode", "—") for u in people)
    by_type = Counter()
    for l in approved_year:
        by_type[policy.get(l["type"], {}).get("name", l["type"])] += l["days"]
    by_month = [0.0] * 12
    for l in leaves:
        if l["status"] in ("Approved", "Pending") and l["from_date"].startswith(year):
            by_month[int(l["from_date"][5:7]) - 1] += l["days"]
    subs = svc.submissions.all()
    if not org_scope:
        subs = [s for s in subs if s["user_id"] in ids]
    by_form = Counter(s["form_title"] for s in subs)

    joiners = sorted(people, key=lambda u: u.get("joined_on", ""), reverse=True)[:5]
    users_by_id = {u.id: u for u in everyone}

    kpis = [
        {"label": "Headcount", "value": len(people), "icon": "bi-people-fill", "color": "indigo",
         "note": f"{len(by_dept)} departments"},
        {"label": "On leave today", "value": len(on_leave_today), "icon": "bi-airplane-engines", "color": "amber",
         "note": f"{(len(on_leave_today) / len(people) * 100 if people else 0):.0f}% of {scope.lower()}"},
        {"label": "Pending leave", "value": len(pending), "icon": "bi-hourglass-split", "color": "coral",
         "note": f"{sum(l['days'] for l in pending):g} days requested"},
        {"label": "Applications", "value": len(subs), "icon": "bi-file-earmark-check", "color": "emerald",
         "note": f"{sum(s['status'] == 'Pending' for s in subs)} awaiting review"},
    ]
    charts = {
        "dept": {"labels": list(by_dept.keys()), "values": list(by_dept.values())},
        "mode": {"labels": list(by_mode.keys()), "values": list(by_mode.values())},
        "type": {"labels": list(by_type.keys()), "values": list(by_type.values())},
        "month": {"labels": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                  "values": by_month},
        "forms": {"labels": list(by_form.keys()), "values": list(by_form.values())},
    }
    return render_template("dashboard/index.html", scope=scope, kpis=kpis, charts=charts,
                           on_leave_today=on_leave_today, pending=pending[:6], joiners=joiners,
                           users=users_by_id, policy=policy)
