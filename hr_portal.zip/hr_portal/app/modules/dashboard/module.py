from app.core.registry import PortalModule

from .routes import bp

MODULE = PortalModule(
    key="dashboard",
    name="Dashboard",
    description="Headcount, leave trends, applications and who's away — at a glance.",
    icon="bi-speedometer2",
    color="indigo",
    permission="dashboard.view",
    permissions={"dashboard.org": "See organisation-wide numbers (otherwise own team only)"},
    blueprint=bp,
    order=10,
    category="Overview",
)
