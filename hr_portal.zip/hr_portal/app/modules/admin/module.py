from app.core.registry import PortalModule

from .routes import bp

MODULE = PortalModule(
    key="admin",
    name="Administration",
    description="Manage users, roles and which modules each role can open.",
    icon="bi-shield-lock",
    color="slate",
    permission="admin.view",
    blueprint=bp,
    order=95,
    category="Manage",
)
