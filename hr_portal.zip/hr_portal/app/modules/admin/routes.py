"""Administration: users, roles & permission matrix, installed modules and forms."""
from __future__ import annotations

import re

from flask import Blueprint, current_app, flash, g, redirect, render_template, request, url_for

from app.core.registry import get_registry
from app.services import services

bp = Blueprint("admin", __name__, template_folder="templates")

USER_FIELDS = ("name", "email", "emp_id", "designation", "department", "grade", "location",
               "work_mode", "phone", "manager_id", "joined_on")


@bp.route("/")
def index():
    return redirect(url_for(".users"))


# ------------------------------------------------------------------ users
@bp.route("/users")
def users():
    svc = services()
    q = request.args.get("q", "").strip().lower()
    role = request.args.get("role", "")
    people = svc.users.all()
    if q:
        people = [u for u in people if q in f"{u.name} {u.username} {u.email} {u.emp_id}".lower()]
    if role:
        people = [u for u in people if role in u.roles]
    return render_template("admin/users.html", people=sorted(people, key=lambda u: u.name),
                           all_users=svc.users.all(), roles=svc.roles.all(), q=q, role=role,
                           departments=svc.users.departments(), perm_groups=get_registry().all_permissions())


@bp.route("/users/<user_id>", methods=["POST"])
def update_user(user_id):
    svc = services()
    roles = [r for r in request.form.getlist("roles") if r in svc.roles.all()]
    if user_id == g.user.id and ("admin" in g.user.roles) and "admin" not in roles:
        flash("You can't remove your own Administrator role.", "danger")
        return redirect(url_for(".users"))
    active = bool(request.form.get("active"))
    if user_id == g.user.id and not active:
        flash("You can't deactivate your own account.", "danger")
        return redirect(url_for(".users"))
    data = {k: request.form.get(k, "").strip() for k in USER_FIELDS if k in request.form}
    if "manager_id" in data:
        data["manager_id"] = data["manager_id"] or None
        if data["manager_id"] == user_id:
            data["manager_id"] = None
    svc.users.update(user_id, roles=roles, active=active,
                     extra_permissions=request.form.getlist("extra_permissions"),
                     revoked_permissions=request.form.getlist("revoked_permissions"), **data)
    flash("User updated.", "success")
    return redirect(url_for(".users", q=request.args.get("q", "")))


@bp.route("/users/new", methods=["POST"])
def create_user():
    svc = services()
    f = request.form
    data = {k: f.get(k, "").strip() for k in USER_FIELDS}
    data["username"] = f.get("username", "").strip()
    data["manager_id"] = data.get("manager_id") or None
    data["roles"] = f.getlist("roles") or ["employee"]
    data["avatar_color"] = f.get("avatar_color") or "indigo"
    data["employment_type"] = "Full-time"
    data["skills"] = []
    password = f.get("password", "")
    missing = [k for k in ("name", "username", "email", "emp_id", "designation", "department") if not data.get(k)]
    if missing:
        flash("Fill in: " + ", ".join(m.replace("_", " ") for m in missing) + ".", "danger")
    elif not re.fullmatch(r"[a-zA-Z0-9._-]{3,30}", data["username"]):
        flash("Usernames use 3–30 letters, numbers, dots, dashes or underscores.", "danger")
    elif len(password) < 8:
        flash("Set an initial password of at least 8 characters.", "danger")
    else:
        if not data.get("joined_on"):
            data.pop("joined_on")
        try:
            u = svc.users.create(data, password)
            flash(f"Created {u.name} ({u.username}).", "success")
        except ValueError as exc:
            flash(str(exc), "danger")
    return redirect(url_for(".users"))


@bp.route("/users/<user_id>/password", methods=["POST"])
def reset_password(user_id):
    pwd = request.form.get("password", "")
    if len(pwd) < 8:
        flash("Temporary passwords need at least 8 characters.", "danger")
    else:
        services().users.set_password(user_id, pwd)
        flash("Password reset. Share it with the user securely.", "success")
    return redirect(url_for(".users"))


# ------------------------------------------------------------------ roles
@bp.route("/roles", methods=["GET", "POST"])
def roles():
    svc = services()
    if request.method == "POST":
        all_roles = svc.roles.all()
        for key in all_roles:
            if key == "admin":
                continue  # administrator always keeps "*"
            svc.roles.set_permissions(key, request.form.getlist(f"perm__{key}"))
        flash("Permissions saved. They apply from the user's next page load.", "success")
        return redirect(url_for(".roles"))
    return render_template("admin/roles.html", roles=svc.roles.all(), perm_groups=get_registry().all_permissions(),
                           members={k: sum(k in u.roles for u in svc.users.all()) for k in svc.roles.all()})


@bp.route("/roles/new", methods=["POST"])
def create_role():
    key = re.sub(r"[^a-z0-9_]", "_", request.form.get("key", "").strip().lower())
    label = request.form.get("label", "").strip()
    if not key or not label:
        flash("A role needs a key and a label.", "danger")
    else:
        try:
            services().roles.create(key, label, request.form.get("description", "").strip())
            flash(f"Role '{label}' created. Tick its permissions below.", "success")
        except ValueError as exc:
            flash(str(exc), "danger")
    return redirect(url_for(".roles"))


@bp.route("/roles/<key>/delete", methods=["POST"])
def delete_role(key):
    try:
        services().roles.delete(key)
        flash("Role deleted.", "info")
    except ValueError as exc:
        flash(str(exc), "danger")
    return redirect(url_for(".roles"))


# ------------------------------------------------------------------ modules
@bp.route("/modules")
def modules():
    from app.modules.forms.routes import library
    lib = library()
    return render_template("admin/modules.html", modules=get_registry().all(),
                           disabled=current_app.config.get("DISABLED_MODULES", []),
                           forms=lib.all(), form_errors=lib.errors)


@bp.route("/reset-demo", methods=["POST"])
def reset_demo():
    services().store.reset()
    flash("Demo data restored to its original state.", "info")
    return redirect(url_for(".modules"))
