from app.core.registry import PortalModule

from .routes import bp

MODULE = PortalModule(
    key="profile",
    name="My Profile",
    description="Your employment details, contact information, access rights and password.",
    icon="bi-person-circle",
    color="pink",
    permission="profile.view",
    blueprint=bp,
    order=90,
    category="Workspace",
)
