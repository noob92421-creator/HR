from __future__ import annotations

import re

from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from app.core.registry import get_registry
from app.services import services

bp = Blueprint("profile", __name__, template_folder="templates")

EDITABLE = ("phone", "address", "emergency_contact")
PHONE_RE = re.compile(r"^\+?[0-9 ()-]{7,20}$")


@bp.route("/")
def index():
    svc = services()
    record = svc.users.profile_record(g.user)
    modules = get_registry().for_user(g.user)
    return render_template("profile/index.html", record=record, modules=modules,
                           roles=svc.roles.all())


@bp.route("/update", methods=["POST"])
def update():
    data = {k: request.form.get(k, "").strip() for k in EDITABLE}
    if data["phone"] and not PHONE_RE.match(data["phone"]):
        flash("Enter a valid phone number.", "danger")
    else:
        services().users.update(g.user.id, **data)
        flash("Contact details updated.", "success")
    return redirect(url_for(".index"))


@bp.route("/password", methods=["POST"])
def password():
    users = services().users
    cur, new, confirm = (request.form.get(k, "") for k in ("current", "new", "confirm"))
    if not users.check_password(g.user.id, cur):
        flash("Your current password is incorrect.", "danger")
    elif len(new) < 8 or not re.search(r"[A-Za-z]", new) or not re.search(r"\d", new):
        flash("Use at least 8 characters, with letters and numbers.", "danger")
    elif new != confirm:
        flash("The new passwords don't match.", "danger")
    else:
        users.set_password(g.user.id, new)
        flash("Password changed.", "success")
    return redirect(url_for(".index", _anchor="security"))
