"""Application factory."""
from __future__ import annotations

from flask import Flask, render_template

from config import Config


def create_app(config_object=Config, **overrides) -> Flask:
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object)
    app.config.update(overrides)

    # 1. data services (JSON stand-in for the database)
    from .services import init_services
    init_services(app)

    # 2. request hooks — order matters: user first, then CSRF, then module guard
    from .core.security import csrf_protect, load_user
    app.before_request(load_user)
    app.before_request(csrf_protect)

    # 3. core pages
    from .core.routes import auth_bp, main_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)

    # 4. plug-and-play modules (auto-discovered from app/modules/)
    from .core.registry import ModuleRegistry
    ModuleRegistry().init_app(app)

    # 5. template helpers
    from .core.templating import init_templating
    init_templating(app)

    # 6. friendly error pages
    for code in (400, 403, 404, 500):
        app.register_error_handler(code, lambda e, code=code: (
            render_template("errors/error.html", code=code, error=e), code))

    return app
